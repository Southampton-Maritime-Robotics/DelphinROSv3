#!/usr/bin/python
import roslib
roslib.load_manifest('DelphinROSv2')
import rospy
import cv as cv2
import time

def run():
    #z = 0    
    #while z == 0: 
    input_video0 = cv2.CaptureFromCAM(0)
#   input_video = cv.CaptureFromFile("AVI_DivX.avi")
#   print input_video
    cv2.NamedWindow('forward_window', cv2.CV_WINDOW_AUTOSIZE)
    
    print 'initial stuff'
    #time.sleep(10)
    while True:
        print 'entered loop'
	image0 = cv2.CaptureFromCAM(0);
        print 'query 0'
# 	cv.NamedWindow("display", 1)

#	print 'should have shown image by now...'
#	time.sleep(10)
    #!/usr/bin/python

        #image=cv.LoadImage('cat-16.jpg', cv.CV_LOAD_IMAGE_COLOR) #Load the image
        
        #g_capture = cv.CaptureFromFile('out.avi')
        #g_capture = cv.CaptureFromAVI('box.avi')
        #g_capture = cv.CaptureFromCAM(1)
        #print image
        #font = cv2.InitFont(cv2.CV_FONT_HERSHEY_SIMPLEX, 1, 1, 0, 3, 8) #Creates a font
        #x = 50
        #y = 50
        #cv.PutText(image,"Hello World!!!", (x,y),font, 255) #Draw the text
        cv2.ShowImage('forward_window', image0) #Show the image
        time.sleep(2)
        cv2.SaveImage('image.png', image0) #Saves the image
        print 'save image'


if __name__ == '__main__':
    run()
