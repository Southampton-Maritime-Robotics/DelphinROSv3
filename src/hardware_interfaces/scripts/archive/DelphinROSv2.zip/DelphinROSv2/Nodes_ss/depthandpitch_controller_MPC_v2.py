#!/usr/bin/python
import roslib; roslib.load_manifest('DelphinROSv2')
import rospy
import serial
import time
import numpy as np
import scipy 
from scipy import linalg
from math  import *

from DelphinROSv2.msg import tsl_setpoints
from DelphinROSv2.msg import tail_setpoints
from DelphinROSv2.msg import position
from DelphinROSv2.msg import compass
from DelphinROSv2.msg import depthandpitch_MPC
from std_msgs.msg import Float32
from std_msgs.msg import Bool


################################################################################
#### CONTROLLER PARAMETERS #####################################################
################################################################################

def set_params():
    global M
    global gamma0
    global C
    global Model
    global iter
    global gain

    #### MODEL VALUES ####
    C.buoyancy      =-3.7
    C.Ltf           = 0.55
    C.Ltr           = 0.49
    C.mdepth        = 167.5
    C.kdepth        = 20 #35 #51.12
    C.ipitch        = 70
    C.kpitch        = 22 #15 #4.0477
    C.gpitch        = 0.1461
    #####################

    #### CONTROLLER VALUES ####
    iter            = 30
    C.Np            = 100
    C.Nc            = 3
    C.delta_t       = 0.1
    C.gain_buoyancy = 0.0001
    C.gain_depth    = 0.01
    C.gain_pitch    = 0.12
    gain = np.eye(C.Nc*2,C.Nc*2)*C.gain_depth
    gain[C.Nc:C.Nc*2,C.Nc:C.Nc*2] = np.eye(C.Nc,C.Nc)*C.gain_pitch
    #####################
    
    #### CONSTRAINTS ####
    C.dtMax         =  1
    C.dtMin         = -1
    C.Tmax          =  6
    C.Tmin          =  0.7
    C.Thrust_Smin   =  0
    C.Thrust_Smax   =  2300
    #####################
    
    #### DEPTH MODEL ####
    Ac_depth = np.matrix([[0, 1],[0, (-C.kdepth/C.mdepth)]])
    Bc_depth = np.matrix([[0, 0],[1, 1]])
    Cc_depth = np.matrix([(1.0/C.mdepth), 0])
    Dc_depth = np.matrix([0, 0])
    print Dc_depth
    #####################
    
    #### PITCH MODEL ####
    Ac_pitch = np.matrix([[0, 1],[(-180*C.gpitch/(C.ipitch*pi)), (-C.kpitch/C.ipitch)]])
    Bc_pitch = np.matrix([[0, 0],[-C.Ltf, C.Ltr]])
    Cc_pitch = np.matrix([(180.0/(pi*C.ipitch)), 0])
    Dc_pitch = np.matrix([0, 0])
    #####################
    
    #### MIMO MODEL ####
    [rd,cd] = np.shape(Ac_depth)
    [rp,cp] = np.shape(Ac_pitch)
    Ac = np.zeros([rd+rp,cd+cp],float)
    Ac[0:rd,0:cd] = Ac_depth
    Ac[rd:rd+rp,cd:cd+cp] = Ac_pitch
    
    [rd,cd] = np.shape(Bc_depth)
    [rp,cp] = np.shape(Bc_pitch)
    Bc = np.zeros([rd+rp,cp],float)
    Bc[0:rd,0:cd] = Bc_depth
    Bc[rd:rd+rp,0:cd] = Bc_pitch
    
    [rd,cd] = np.shape(Cc_depth)
    [rp,cp] = np.shape(Cc_pitch)
    Cc = np.zeros([rd+rp,cp + cd],float)
    Cc[0:rd,0:cd] = Cc_depth
    Cc[rd:rd+rp,cd:cd+cp] = Cc_pitch
    Dc = np.zeros([rd+rp,cd],float)
    
    SYS = tuple([Ac, Bc, Cc, Dc])
    [Ad, Bd, Cd, Dd] = cont2discrete(SYS,C.delta_t)
    [rd,cd] = np.shape(Bd)
    Zd = np.zeros([rd,cd],float)
    Zd[0:rd/2,:] = Bd[0:rd/2,:]
    Model = tuple([Ad, Bd, Cd, Dd, Zd])
    
    #### CONSTRAINTS ####
    [rd,cd] = np.shape(Bc_depth) 
    gamma0 = np.transpose(np.matrix([C.dtMax, C.dtMax, -C.dtMin, -C.dtMin, C.Tmax, C.Tmax, -C.Tmin, -C.Tmin]))
    M = np.zeros([np.size(gamma0),cd*C.Nc],float)
    M[:,0:2] = np.matrix([[1, 0],[0, 1],[-1, 0],[0, -1],[1, 0],[0, 1],[-1, 0],[0, -1]])
    #####################

################################################################################
########## MAIN CONTROL LOOP ###################################################
################################################################################

def main_control_loop():

    #### SETUP ####
    global compass
    global C
    
    C                = depthandpitch_MPC()
    C.pitch_demand   = 0.0
    C.depth_demand   = 0.0
    compass          = compass()
    C.onOFF          = False
    
    set_params()
    [Ad, Bd, Cd, Dd, Zd] = Model

    x = time.time()
    [Phi_Phi, Phi_F, Phi_R, A_e, B_e, C_e] = mpc_gain(C.Np, C.Nc, Ad, Bd, Cd, Dd)
    time_zero        = time.time()
    
    [n,n_in] = np.shape(B_e)
    xm = np.zeros([4,1],float)
    Xf = np.zeros([6,1],float)
    
    u = np.matrix([[0],[0]])
    buoyancy = np.matrix([[C.buoyancy*C.Ltr/(C.Ltr+C.Ltf)], [C.buoyancy*C.Ltf/(C.Ltr+C.Ltf)]])
    
    E = Phi_Phi + gain #np.dot(C.gain_rw,np.eye(C.Nc*n_in,C.Nc*n_in))
    print 'time = ',time.time()-x
################################################################################        
    while not rospy.is_shutdown():
        dt = time.time() - time_zero
        

        if dt >= C.delta_t and C.onOFF == True:
            
            time_zero = time.time()            
            demands = np.matrix([[C.depth_demand],[C.pitch_demand]])
            
            ### Depth controller ###############################################
            F = -(np.dot(Phi_R,demands) - np.dot(Phi_F,Xf))               
            gamma = gamma0 + np.matrix([[0], [0], [0], [0], [-u[0]], [-u[1]], [u[0]], [u[1]]])

            [Delta_u, C.km] = QPhild(E,F,M,gamma)
            
            C.dT0 = float(Delta_u[0,0])
            C.dT1 = float(Delta_u[1,0])
            u[0]  = C.T0  = float(u[0] + C.dT0)
            u[1]  = C.T1  = float(u[1] + C.dT1)
            
            C.buoyancy = C.buoyancy - xm[1]*C.gain_buoyancy/np.exp(2*(demands[0] - compass.depth))  #C.buoyancy
            buoyancy[0] = C.buoyancy*C.Ltr/(C.Ltr+C.Ltf) #(1 - 0.03914*compass.depth)*
            buoyancy[1] = C.buoyancy*C.Ltf/(C.Ltr+C.Ltf)

            xm_old = xm
            xm = np.dot(Ad,xm) + np.dot(Bd,u) + np.dot(Zd,buoyancy)
                        
            Xf[0:n-2]   = xm - xm_old
            Xf[n-2:n-1] = C.depth = compass.depth
            Xf[n-1:n]   = C.pitch = compass.pitch
            
            ####################################################################
            C.thruster0 =  int(limits((1.13*np.sign(C.T0)*(60*(np.abs(C.T0)/(1000*0.46*0.07**4))**0.5)), C.Thrust_Smin, C.Thrust_Smax))
            C.thruster1 =  int(limits((1.13*np.sign(C.T1)*(60*(np.abs(C.T1)/(1000*0.46*0.07**4))**0.5)), C.Thrust_Smin, C.Thrust_Smax))
            ####################################################################
            
            ####################################################################
            C.calc_time = time.time() - time_zero
            #print 'Calc time = ',C.calc_time
            ####################################################################

            ### Publish values #################################################
            pub_tsl.publish(thruster0 = C.thruster0, thruster1 = C.thruster1)
            pub_C.publish(C)            
            ####################################################################
            
                        
######## END OF LOW LEVEL CONTROLLER ###########################################
################################################################################
################################################################################

################################################################################
################################################################################
def QPhild(E,F,M,gamma):
    
    km = 0
    [n1,m1] = np.shape(M)
    eta = -np.dot(np.linalg.inv(E),F) 
    
    kk = 0
    i = 0
   
    while i < n1:
        if np.dot(M[i,:],eta) > gamma[i]:
            kk = kk + 1
            i = i + 1
        else:
            kk = kk + 0
            i = i + 1
            
    if kk == 0:
        return [eta, km]
            
    H = np.dot(M,(np.dot(np.linalg.inv(E),np.transpose(M))))
    K = np.dot(M,(np.dot(np.linalg.inv(E),F))) + gamma
    
    [n,m] = np.shape(K)
    
    Lambda =  np.zeros([n,m],float)
    Lambda_p = np.zeros([n,m],float)
    x = np.zeros([n,m],float)
    al = 10

    while km < iter:

        Lambda_p[:,0] =  Lambda[:,0]        
        i = 0
        while i < n:
            w = np.dot(H[i,:],Lambda) - np.dot(H[i,i],Lambda[i,0])
            w = w + K[i,0]
            la = -w/H[i,i]
            Lambda[i,0] = np.max([0, la])        
            i = i + 1
        
        al = np.dot(np.transpose(Lambda - Lambda_p),(Lambda - Lambda_p))
        
        km = km + 1

        if al < 10e-8:
            break
    
    eta = -np.dot(np.linalg.inv(E),F) - np.dot(np.linalg.inv(E),(np.dot(np.transpose(M),Lambda))) 
    
    return [eta, km]
################################################################################
################################################################################

################################################################################
################################################################################
def mpc_gain(Np,Nc,Ad,Bd,Cd,Dd):
   
    [m1,n1]   = np.shape(Cd)
    [n1,n_in] = np.shape(Bd)
    
    A_e = np.eye(n1+m1,n1+m1)
    A_e[0:n1,0:n1] = Ad
    A_e[n1:n1+m1,0:n1] = np.dot(Cd,Ad)
            
    B_e = np.zeros([n1+m1,n_in],float)
    B_e[0:n1,:] = Bd;
    B_e[n1:n1+m1,:] = np.dot(Cd,Bd)
    
    C_e = np.zeros([m1,n1+m1],float)
    C_e[:,n1:n1+m1] = np.eye(m1,m1)

    n = n1+m1
    P = np.zeros([Np*m1,m1],float)
    F = np.zeros([Np*m1,n],float)
    
    P[0:m1,0:m1] = np.dot(C_e,B_e)
    F[0:m1,0:n]  = np.dot(C_e,A_e)
    
    kk = 1
    while kk < Np:
        F[kk*m1:(kk+1)*m1,:] = np.dot(F[(kk-1)*m1:kk*m1,:],A_e)        
        P[kk*m1:(kk+1)*m1,:] = np.dot(F[(kk-1)*m1:kk*m1,:],B_e)
        kk = kk+1
    
    Phi = np.zeros([Np*m1,Nc*m1],float)
    Phi[:,0:m1] = P
    
    i = 1
    while i < Nc:
        Phi[0:i*m1,i*m1:(i+1)*m1] = np.zeros([i*m1,m1],float)
        Phi[i*m1:Np*m1,i*m1:(i+1)*m1] = P[0:Np*m1-i*m1,0:m1]
        i = i + 1    
    
    Phi_Phi = np.dot(np.transpose(Phi),Phi)
    Phi_F = np.dot(np.transpose(Phi),F)
    Phi_R = Phi_F[:,4:6]

    return [Phi_Phi, Phi_F, Phi_R, A_e, B_e, C_e]
################################################################################
################################################################################

################################################################################
################################################################################
def cont2discrete(sys, dt, method="zoh", alpha=None):
    
    if len(sys) == 4:
        a, b, c, d = sys
    else:
        raise ValueError("First argument must either be a tuple of 4 (ss) arrays.")
    
    if method == 'zoh':
        # Build an exponential matrix
        em_upper = np.hstack((a, b))

        # Need to stack zeros under the a and b matrices
        em_lower = np.hstack((np.zeros((b.shape[1], a.shape[0])),
                              np.zeros((b.shape[1], b.shape[1])) ))
        em = np.vstack((em_upper, em_lower))
        ms = linalg.expm(dt * em)

        # Dispose of the lower rows
        ms = ms[:a.shape[0], :]
        ad = ms[:, 0:a.shape[1]]
        bd = ms[:, a.shape[1]:]
        cd = c
        dd = d

    else:
        raise ValueError("Unknown transformation method '%s'" % method)

    return ad, bd, cd, dd

################################################################################
################################################################################

def limits(value, min, max):       #Function to contrain within defined limits
    if value < min:				   
       value = min
    elif value > max:
       value = max
    return value
    
################################################################################
################################################################################

def depth_demand_cb(depthd):
    global C
    C.depth_demand = depthd.data
    
def pitch_demand_cb(pitchd):
    global C
    C.pitch_demand = pitchd.data
    print 'NEW PITCH DEMAND!!!! ',C.pitch_demand
def compass_cb(data):
    global compass
    compass  = data 

def depth_onOff_cb(onOff):
    global DC
    C.onOFF = onOff.data
    
def pitch_onOff_cb(onOff):
    global PC
    #PC.onOFF = onOff.data

################################################################################
#### INITIALISATION ############################################################
################################################################################

if __name__ == '__main__':

    rospy.init_node('MPC_Depth_controller')
    
    global depth_onOff
    global pitch_onOff
    
    rospy.Subscriber('depth_demand', Float32, depth_demand_cb)
    rospy.Subscriber('pitch_demand', Float32, pitch_demand_cb)
    rospy.Subscriber('compass_out', compass, compass_cb)
    rospy.Subscriber('Depth_onOFF', Bool, depth_onOff_cb)
    rospy.Subscriber('Pitch_onOFF', Bool, pitch_onOff_cb)
    
    
    pub_tsl  = rospy.Publisher('TSL_setpoints_vertical', tsl_setpoints)
    pub_C   = rospy.Publisher('DepthandPitch_MPC_values', depthandpitch_MPC)
    
    rospy.loginfo("Depth controller online")

    main_control_loop()
