#!/usr/bin/python
import roslib; roslib.load_manifest('DelphinROSv2')
import rospy
import serial
import time
import numpy as np
import scipy 
from scipy import linalg
from math  import *

from DelphinROSv2.msg import tsl_setpoints
from DelphinROSv2.msg import tail_setpoints
from DelphinROSv2.msg import position
from DelphinROSv2.msg import compass
from DelphinROSv2.msg import depthandpitch_MPC
from std_msgs.msg import Float32
from std_msgs.msg import Bool


################################################################################
#### CONTROLLER PARAMETERS #####################################################
################################################################################

def set_params():                                                               # Set controller parameters and build model
    global M
    global gamma0
    global C
    global Model
    global iter
    global gain

    #### MODEL VALUES ####
    C.Ltf           =-0.55                                                      # Moment arm of front thruster
    C.Ltr           = 0.49                                                      # Moment arm of rear thruster
    C.mdepth        = 167.5                                                     # Mass (inc added) 
    C.kdepth        = 20.0                                                      # Linear drag coeff in Z axis
    C.ipitch        = 70.0                                                      # Inertia about pitch axis
    C.kpitch        = 4                                                         # Linear drag coeff in pitch axis
    C.gpitch        = 85.0 * 9.81 * 0.011 * 0.9686                              # mass x gravity x BG x sin.gradient
    #####################

    #### CONTROLLER VALUES ####
    iter            = 30                                                        # Maximum iterations of Hildreth algorithm
    C.Np            = 100                                                       # Length of prediction horizon
    C.Nc            = 3                                                         # Length of control horizon
    C.delta_t       = 0.1                                                       # Period of controller
    C.gain          = 0.1                                                       # Controller gain
    #####################
    
    #### CONSTRAINTS ####
    C.dtMax         =  2                                                        # Max change in thrust per control loop (N)
    C.dtMin         = -2                                                        # Min change in thrust per control loop (N)
    C.Tmax          =  8                                                        # Max allowable thrust (N)
    C.Tmin          =  0.7                                                      # Min allowable thrust (N)
    C.Thrust_Smax   =  2300                                                     # Max thruster speed (rpm)
    C.Thrust_Smin   =  0                                                        # Min thruster speed (rpm)
    #####################
    
    #### DEPTH MODEL ####                                                       # State space model (2 DoF)
    Ac = np.matrix([[0, 1, 0, 0], [0, (-C.kdepth/C.mdepth), 0, 0], [0, 0, 0, 1], [0, 0, (-C.gpitch/C.ipitch), (-C.kpitch/C.ipitch)]])
    Bc = np.matrix([[0, 0], [1/C.mdepth, 1/C.mdepth], [0, 0], [C.Ltf/C.ipitch, C.Ltr/C.ipitch]])
    Cc = np.matrix([[1, 0, 0, 0], [0, 0, 1, 0]])
    Dc = np.matrix([[0, 0], [0, 0]])
    
    print 'G = ',(-C.gpitch/C.ipitch)
       
    SYS = tuple([Ac, Bc, Cc, Dc])
    [Ad, Bd, Cd, Dd] = cont2discrete(SYS,C.delta_t)                             # Convert continuous SS model to discrete
    [rd,cd] = np.shape(Bd)
    Model = tuple([Ad, Bd, Cd, Dd])                                             # Collect discrete model into one tuple
        
    #### CONSTRAINTS ####
    [rd,cd] = np.shape(Bc) 
    gamma0 = np.transpose(np.matrix([C.dtMax, C.dtMax, -C.dtMin, -C.dtMin, C.Tmax, C.Tmax, -C.Tmin, -C.Tmin])) # Itialise gamma for controlling constaints
    M = np.zeros([np.size(gamma0),cd*C.Nc],float)
    M[:,0:2] = np.matrix([[1, 0],[0, 1],[-1, 0],[0, -1],[1, 0],[0, 1],[-1, 0],[0, -1]]) # M matrix used for defining constaints
    #####################

################################################################################
########## MAIN CONTROL LOOP ###################################################
################################################################################

def main_control_loop():

    #### SETUP ####
    global compass
    global C
    
    C                = depthandpitch_MPC()                                      # Create C structure using message type
    C.pitch_demand   = 0.0                                                      # Initialise pitch demand to zero
    C.depth_demand   = 0.0                                                      # Initialise depth demand to zero
    compass          = compass()                                                # Create compass structure using message type
    C.onOFF          = False                                                    # Initialise controller onOff to OFF
    
    set_params()                                                                # Set parameters and build model (see above)
    [Ad, Bd, Cd, Dd] = Model                                                    # Load model into main loop

    [Phi_Phi, Phi_F, Phi_R, A_e, B_e, C_e] = mpc_gain(C.Np, C.Nc, Ad, Bd, Cd, Dd) # Create augmented model
    
    time_zero = time.time()                                                     # Create time zero
    [n,n_in]  = np.shape(B_e)
    xm        = np.zeros([4,1],float)                                           # Initialise states
    Xf        = np.zeros([6,1],float)                                            
    u         = np.matrix([[0.0],[0.0]])                                        # Initialise input values
    
#    gD = 0.1
#    gP = 10
#    gain = np.eye(C.Nc*n_in,C.Nc*n_in)
#    gain[0,0] = gD
#    gain[1,1] = gP
#    gain[2,2] = gD
#    gain[3,3] = gP
#    gain[4,4] = gD
#    gain[5,5] = gP
    
#    E = Phi_Phi + gain
    E = Phi_Phi + np.dot(C.gain,np.eye(C.Nc*n_in,C.Nc*n_in))                    # Calculate E matrix
    
    pitch_old = 0
    
################################################################################        
    while not rospy.is_shutdown():
        dt = time.time() - time_zero                                            # Calculate time since last calculation
        

        if dt >= C.delta_t and C.onOFF == True:                                 # If dt >= controller period and controller is on then proceed
        
            C.depth = compass.depth
            C.pitch = compass.pitch
            
            time_zero = time.time()                                             # Set time zero
            demands = np.matrix([[C.depth_demand],[C.pitch_demand]])            # Set demands 
            
            ### Depth controller ###############################################
            F = -(np.dot(Phi_R,demands) - np.dot(Phi_F,Xf))                     # Calculate F matrix
            gamma = gamma0 + np.matrix([[0], [0], [0], [0], [-u[0]], [-u[1]], [u[0]], [u[1]]]) # Calculate gamma for controlling constaints

            [Delta_u, C.km] = QPhild(E,F,M,gamma,time_zero)                               # Find optimum control horizon within constaints
            
            C.dT0 = float(Delta_u[0,0])                                         # Change in thrust for front thruster
            C.dT1 = float(Delta_u[1,0])                                         # Change in thrust for rear thruster
            u[0]  = C.T0  = float(u[0] + C.dT0)                                 # Add delta_thrust to previous thrust value
            u[1]  = C.T1  = float(u[1] + C.dT1)                                 # Add delta_thrust to previous thrust value
            
            xm_old = xm                                                         # Save previous system state as xm_old
            xm     = np.dot(Ad,xm) + np.dot(Bd,u)                               # Calculate new system state using SS model
            
            C.xm0  = xm[0]
            C.xm1  = xm[1]
            C.xm2  = xm[2]
            C.xm3  = xm[3]
            
            
            
            xm[0]  = compass.depth                                              # Set depth state to measured depth
            #xm[2]  = compass.pitch*pi/180                                       # Set pitch state to measured pitch 
            #xm[3]  = compass.pitch*pi/180 - pitch_old                                       # Set pitch state to measured pitch 
            y      = np.matrix([[compass.depth],[compass.pitch*pi/180]])               # Set y to measured depth and pitch
                                                
            Xf[0:n-2]   = xm - xm_old                                           # Create Xf array for use in calculating F
            Xf[n-2:n]   = y
            
            print 'xm[2] = ',xm[2]
            print 'pitch*pi/180 = ',compass.pitch*pi/180      
            
            ##################################################################### Convert thrust values to thruster setpoints within hard limits
            C.thruster0 =  int(limits((1.13*np.sign(C.T0)*(60*(np.abs(C.T0)/(1000*0.46*0.07**4))**0.5))  , C.Thrust_Smin, C.Thrust_Smax))
            C.thruster1 =  int(limits((1.13*np.sign(C.T1)*(60*(np.abs(C.T1)/(1000*0.46*0.07**4))**0.5)), C.Thrust_Smin, C.Thrust_Smax))
            ####################################################################
            
            ####################################################################
            C.calc_time = time.time() - time_zero                               # Calculate time taken to do calculations
            ####################################################################

            ### Publish values #################################################
            pub_tsl.publish(thruster0 = C.thruster0, thruster1 = C.thruster1)   # Publish thruster setpoints
            pub_C.publish(C)                                                    # Publish controller data
            ####################################################################
            
                        
######## END OF LOW LEVEL CONTROLLER ###########################################
################################################################################
################################################################################

################################################################################
################################################################################
def QPhild(E,F,M,gamma,time_zero):                                                        # Find optimum control horizon within constraints
    
    km      = 0                                                                 # Hildreth iterations equals zero
    [n1,m1] = np.shape(M)
    eta     = -np.dot(np.linalg.inv(E),F)                                       # Find optimum control horizon
    
    kk = 0                                                                      # Number of constaint violations set to zero
    i  = 0
   
    while i < n1:                                                               # Loop through each constaint line
        if np.dot(M[i,:],eta) > gamma[i]:                                       # If optimum solution is exceeds constraints...
            kk = kk + 1                                                         # Increase count of constain violations
            i = i + 1
        else:                                                                   # Do nothing then proceed
            kk = kk + 0
            i = i + 1
            
    if kk == 0:                                                                 # If constaints have not been violated with optimum solution then return
        return [eta, km]
            
    H = np.dot(M,(np.dot(np.linalg.inv(E),np.transpose(M))))                    # Calculate H matrix
    K = np.dot(M,(np.dot(np.linalg.inv(E),F))) + gamma                          # Calculate K matrix
    
    [n,m] = np.shape(K)
    
    Lambda =  np.zeros([n,m],float)                                             # Initialise correction term lambda
    Lambda_p = np.zeros([n,m],float)                                            # Initialise 'old' correction term lambda_p

    al = 10                                                                     # Initialise convergance criterium to greater than 10e-8

    while km < iter:                                                            # While number of iterations is less than permitted

        Lambda_p[:,0] =  Lambda[:,0]                                            # Set Lambda_p to old lambda before calculating the new one
        i = 0
        while i < n:
            w = np.dot(H[i,:],Lambda) - np.dot(H[i,i],Lambda[i,0])
            w = w + K[i,0]
            la = -w/H[i,i]
            Lambda[i,0] = np.max([0, la])        
            i = i + 1
        
        al = np.dot(np.transpose(Lambda - Lambda_p),(Lambda - Lambda_p))        # Calculate square of difference between new and old lambda
        
        km = km + 1

        if (al < 10e-8) or ((time.time() - time_zero) > (C.delta_t - 0.01)):                                                          # Check convergance criterium and if within limit break
            break
    
    eta = -np.dot(np.linalg.inv(E),F) - np.dot(np.linalg.inv(E),(np.dot(np.transpose(M),Lambda))) # Calculate optimum within constaints
    
    return [eta, km]                                                            # Return solution and number of Hildreth algorithm iterations
################################################################################
################################################################################

################################################################################
################################################################################
def mpc_gain(Np,Nc,Ad,Bd,Cd,Dd):                                                # Create augmented model
   
    [m1,n1]   = np.shape(Cd)
    [n1,n_in] = np.shape(Bd)
    
    A_e = np.eye(n1+m1,n1+m1)
    A_e[0:n1,0:n1] = Ad
    A_e[n1:n1+m1,0:n1] = np.dot(Cd,Ad)
            
    B_e = np.zeros([n1+m1,n_in],float)
    B_e[0:n1,:] = Bd;
    B_e[n1:n1+m1,:] = np.dot(Cd,Bd)
    
    C_e = np.zeros([m1,n1+m1],float)
    C_e[:,n1:n1+m1] = np.eye(m1,m1)

    n = n1+m1
    P = np.zeros([Np*m1,m1],float)
    F = np.zeros([Np*m1,n1 + m1],float)
    
    P[0:m1,0:m1] = np.dot(C_e,B_e)
    F[0:m1,0:n]  = np.dot(C_e,A_e)
    
    kk = 1
    while kk < Np:
        F[kk*m1:(kk+1)*m1,:] = np.dot(F[(kk-1)*m1:kk*m1,:],A_e)        
        P[kk*m1:(kk+1)*m1,:] = np.dot(F[(kk-1)*m1:kk*m1,:],B_e)
        kk = kk+1
    
    Phi = np.zeros([Np*m1,Nc*m1],float)
    Phi[:,0:m1] = P
    
    i = 1
    while i < Nc:
        Phi[0:i*m1,i*m1:(i+1)*m1] = np.zeros([i*m1,m1],float)
        Phi[i*m1:Np*m1,i*m1:(i+1)*m1] = P[0:Np*m1-i*m1,0:m1]
        i = i + 1    
    
    Phi_Phi = np.dot(np.transpose(Phi),Phi)
    Phi_F = np.dot(np.transpose(Phi),F)
    Phi_R = Phi_F[:,4:6]

    return [Phi_Phi, Phi_F, Phi_R, A_e, B_e, C_e]
################################################################################
################################################################################

################################################################################
################################################################################
def cont2discrete(sys, dt, method="zoh", alpha=None):                           # Convert continous state space model to discrete state space model
    
    if len(sys) == 4:
        a, b, c, d = sys
    else:
        raise ValueError("First argument must either be a tuple of 4 (ss) arrays.")
    
    if method == 'zoh':
        # Build an exponential matrix
        em_upper = np.hstack((a, b))

        # Need to stack zeros under the a and b matrices
        em_lower = np.hstack((np.zeros((b.shape[1], a.shape[0])),
                              np.zeros((b.shape[1], b.shape[1])) ))
        em = np.vstack((em_upper, em_lower))
        ms = linalg.expm(dt * em)

        # Dispose of the lower rows
        ms = ms[:a.shape[0], :]
        ad = ms[:, 0:a.shape[1]]
        bd = ms[:, a.shape[1]:]
        cd = c
        dd = d

    else:
        raise ValueError("Unknown transformation method '%s'" % method)

    return ad, bd, cd, dd

################################################################################
################################################################################

def limits(value, min, max):                                                    # Contrain value within set limits
    if value < min:				   
       value = min
    elif value > max:
       value = max
    return value
    
################################################################################
################################################################################

def depth_demand_cb(depthd):
    global C
    C.depth_demand = depthd.data
    
def pitch_demand_cb(pitchd):
    global C
    C.pitch_demand = pitchd.data

def compass_cb(data):
    global compass
    compass  = data 

def depth_onOff_cb(onOff):
    global DC
    C.onOFF = onOff.data
    
def pitch_onOff_cb(onOff):
    global PC

################################################################################
#### INITIALISATION ############################################################
################################################################################

if __name__ == '__main__':

    rospy.init_node('MPC_Depth_controller')
    
    global depth_onOff
    global pitch_onOff
    
    rospy.Subscriber('depth_demand', Float32, depth_demand_cb)
    rospy.Subscriber('pitch_demand', Float32, pitch_demand_cb)
    rospy.Subscriber('compass_out', compass, compass_cb)
    rospy.Subscriber('Depth_onOFF', Bool, depth_onOff_cb)
    rospy.Subscriber('Pitch_onOFF', Bool, pitch_onOff_cb)
    
    
    pub_tsl  = rospy.Publisher('TSL_setpoints_vertical', tsl_setpoints)
    pub_C    = rospy.Publisher('DepthandPitch_MPC_values', depthandpitch_MPC)
    
    rospy.loginfo("Depth controller online")

    main_control_loop()
