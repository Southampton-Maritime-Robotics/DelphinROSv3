#!/usr/bin/python
import roslib; roslib.load_manifest('DelphinROSv2')
import rospy
import time
import numpy
from std_msgs.msg import Float32
from std_msgs.msg import Int8
from DelphinROSv2.msg import compass as compass_out
from DelphinROSv2.msg import position
from DelphinROSv2.msg import gps
from DelphinROSv2.msg import altitude
import math


######################################
#Modifications
#6/1/12 Modified GPS callback to only operate if a valid fix is returned
#9/2/12 Modified definition of X and Y. X is east and Y is north to be consistant with everything else.


#### DEFINE GLOBAL VARIABLES ####
global flag
global cur_compass
global cur_sway
global cur_prop

########## LOW LEVEL CONTROL ############################################################
def reckoner():

    #### SETUP ####
        global cur_compass
        global cur_sway
        global cur_prop
        global X
        global Y
        global Z
        global flag
	global GPS_flag

        global GPS_X
        global GPS_Y
	global GPS_long
	global GPS_lat
	global lat_orig
	global long_orig
	global altitude_new

        lat_orig = rospy.get_param('lat_orig')
        long_orig = rospy.get_param('long_orig')

        flag = False
	GPS_flag=False
        cur_sway = Float32()
        cur_prop = Float32()
        cur_compass = compass_out()
        time_zero = time.time()	
       

        cur_sway.data = 0.0
        cur_prop.data = 0.0

	Tcx = 3.68 		# Time constant for X direction
	Tcy = 4

	Vx=0.0
	Vy=0.0

	X=0.0000001
	Y=0.0000001
	Z=0.0
	GPS_X=0
	GPS_Y=0
	latitude=0
	longitude=0
	altitude_new=0.0

        print 'Entering main loop!!!'
        #### MAIN RECKONER LOOP ####
        while not rospy.is_shutdown():
	    if GPS_flag==True:
		X=GPS_X
		Y=GPS_Y
		latitude=numpy.float64(GPS_lat)
		longitude=numpy.float64(GPS_long)

	        #### PUBLISH LOCATATION ####
	        output=position()
 	        output.X = X
    	        output.Y = Y
    	        output.Z = cur_compass.depth
                output.forward_vel = GPS_speed
                output.sway_vel =0
	        output.lat=latitude
	        output.long=longitude
	        output.altitude=altitude_new
	        output.ValidGPSfix=1
	        pub.publish(output)
	        GPS_flag=False

                
            elif flag == True:
                
		#### BASIC CALCS ####
                dt = time.time() - time_zero	                # Calculate dt time between last loop interation
                time_zero = time.time()		                # Record time of start of this loop
                print 'Basic calcs done'

		#### Z POSITION ####
                Z=cur_compass.depth
                print 'Z position done'

		#### FORWARD VEL ####
                prop = float(cur_prop.data)
		Vx_ss = -0.0004809*prop**2 + 0.0567*prop	# Calculate steady state forward velocity
                if prop < 0:                                    # If prop demand is in reverse then half the vel setpoint
                    Vx_ss = Vx_ss / 2.0                
		Vx_error = Vx_ss - Vx				# Difference between current vel estimate and steady state
		Vx = Vx+Vx_error*(dt/Tcx)			# First order approximation
                print 'Forward velocity done'
                
		#### SWAY VEL ####
		Vy_ss = float(cur_sway.data)/10000       			# Same as for forward vel section above
		Vy_error = Vy_ss - Vy
		Vy = Vy+Vy_error*(dt/Tcy)
                print 'Sway velocity done'
	
 		#### GET HEADING ####
		heading=cur_compass.heading
    	        print 'heading', heading
		heading= heading/180*numpy.pi

                #### XY VELOCITIES ####
    	        u=Vx*numpy.sin(heading)-Vy*numpy.sin(heading)
    	        v=Vx*numpy.cos(heading)+Vy*numpy.cos(heading)
	
		#### XY LOCATION ####
		X=X+u*dt
		Y=Y+v*dt


		#####Estimate Lat and Long


    
    		# Code from http://www.movable-type.co.uk/scripts/latlong.html
		R = 6367500 #Radius of the earth in m

		brng = numpy.tan2(X/Y)
		d    = numpy.sqrt(X**2+Y**2)
		#brng = numpy.radians(brng)
		lat1 = numpy.radians(lat_orig)
		lon1 = numpy.radians(long_orig)
		lat2 = numpy.asin(numpy.sin(lat1)*numpy.cos(d/R) + numpy.cos(lat1)*numpy.sin(d/R)*numpy.cos(brng))
		lon2 = lon1 + numpy.atan2(numpy.sin(brng)*numpy.sin(d/R)*numpy.cos(lat1), numpy.cos(d/R)-numpy.sin(lat1)*numpy.sin(lat2))
		latitude  = numpy.float64(numpy.degrees(lat2))
		longitude = numpy.float64(numpy.degrees(lon2))
	
		#### PRINT DATA ####
        print 'u', u
        print 'v', v

        print 'X', X
        print 'Y', Y
        print 'Z', Z

	
	        #### PUBLISH LOCATATION ####
        output=position()
        output.X = X
        output.Y = Y
        output.Z = cur_compass.depth
        output.forward_vel = Vx
        output.sway_vel = Vy
        output.lat=latitude
        output.long=longitude
        output.ValidGPSfix=0
        output.altitude=altitude_new
        pub.publish(output)
        flag=False
	


#float32 lat
#float32 long
#float32 altitude
#bool    ValidGPSfix


		#### END OF MAIN DEAD RECKONING LOOP ####

######## END DEAD RECKONER #####################################################


#### WHEN NEW MISSION OR COMPASS DATA ARRIVES UPDATE VALUES AND RESET FLAG ####

def compass_cb(compass):
    global flag
    global cur_compass
    cur_compass = compass   
    print 'new compass data!!' 
    flag = True

def prop_cb(prop):
    global flag
    global cur_prop
    cur_prop = prop   
    print 'new prop data!!' 
    flag = True

def sway_cb(sway):
    global flag
    global cur_sway
    cur_sway = sway
    print 'new sway data!!' 
    flag = True

def gps_callback(gps):
    global GPS_flag
    global GPS_X
    global GPS_Y
    global GPS_speed 
    global GPS_NosOfSat
    global GPS_lat
    global GPS_long

    GPS_lat=gps.latitude
    GPS_long=gps.longitude

    GPS_X=gps.x
    GPS_Y=gps.y
    GPS_NosOfSat=gps.number_of_satelites
    GPS_speed=gps.speed
    if GPS_NosOfSat>=4: #Only use new GPS information if 4 or more satalites
    	GPS_flag=True
        print 'new GPS data'


def altitude_cb(altitude):
    global altitude_new 
    altitude_new = altitude.altitude

#### INITIALISATION ####
if __name__ == '__main__':
    rospy.init_node('dead_reckoner')
    
    rospy.Subscriber('compass_out', compass_out, compass_cb)
    rospy.Subscriber('prop_demand',Int8, prop_cb)
    rospy.Subscriber('sway_demand',Float32, sway_cb)
    rospy.Subscriber('gps_out', gps, gps_callback)
    rospy.Subscriber('altimeter_out', altitude, altitude_cb)
    pub = rospy.Publisher('position_dead', position)

    reckoner()
