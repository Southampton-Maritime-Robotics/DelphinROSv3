#!/usr/bin/python
import roslib
roslib.load_manifest('DelphinROSv2')
import rospy
import cv
import time

def run():
    #z = 0    
    #while z == 0: 
    input_video1 = cv.CaptureFromCAM(-1)
#   input_video = cv.CaptureFromFile("AVI_DivX.avi")
#   print input_video
    cv.NamedWindow('down_window', cv.CV_WINDOW_AUTOSIZE)
    
    print 'initial stuff'

    while True:
	image1 = cv.QueryFrame(input_video1);
        image1 = cv.LoadImageM("cat-16.jpg")
        print 'query 1'

# 	cv.NamedWindow("display", 1)

#	print 'should have shown image by now...'
#	time.sleep(10)
    #!/usr/bin/python

        #image=cv.LoadImage('cat-16.jpg', cv.CV_LOAD_IMAGE_COLOR) #Load the image
        
        #g_capture = cv.CaptureFromFile('out.avi')
        #g_capture = cv.CaptureFromAVI('box.avi')
        #g_capture = cv.CaptureFromCAM(1)
        #print image
        #font = cv.InitFont(cv.CV_FONT_HERSHEY_SIMPLEX, 1, 1, 0, 3, 8) #Creates a font
        #x = 50
        #y = 50
        #cv.PutText(image,"Hello World!!!", (x,y),font, 255) #Draw the text
        cv.ShowImage('down_window', image1) #Show the image
        print 'show image'
        cv.WaitKey(200)
        cv.SaveImage('image.png', image1) #Saves the image
        #print 'save image'


if __name__ == '__main__':
    run()
