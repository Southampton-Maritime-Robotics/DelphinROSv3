#!/usr/bin/env python

import roslib; roslib.load_manifest('DelphinROSv2')
import rospy
import numpy
import smach
import smach_ros
import time
from std_msgs.msg import String


class GoToXYZ(smach.State):
    def __init__(self, lib, X, Y, Z, useCurrentLocAsInitialXY,initialX, initialY,XYtolerance, Ztolerance, XYstable_time, Zstable_time, timeout):
            smach.State.__init__(self, outcomes=['succeeded','aborted','preempted'])
            self.__controller = lib
            self.__X = X
            self.__Y = Y
	    self.__useCurrentLocAsInitialXY=useCurrentLocAsInitialXY
	    self.__initialX=initialX
	    self.__initialY=initialY
            self.__Z = Z
            self.__XYtolerance   = XYtolerance
            self.__Ztolerance    = Ztolerance
            self.__XYstable_time = XYstable_time
            self.__Zstable_time  = Zstable_time
            self.__timeout       = timeout
            self.__at_XY_time    = time.time()
            self.__at_Z_time     = time.time()
            
    def execute(self,userdata):
            global pub
            #Set Up Publisher for Mission Control Log
            pub = rospy.Publisher('MissionStrings', String)
            time_zero = time.time()
            at_depth_time = 0
            at_depth = False
            self.__controller.setDepth(self.__Z)
            dt = 0
            
            str='Entered goTOXYZ State at %s' %time_zero
            pub.publish(str)
	    rospy.loginfo(str)
            str='Desired Position X=%s, Y=%s and depth=%s' %(self.__X, self.__Y,self.__Z) 
            pub.publish(str)
            rospy.loginfo(str)

	    if self.__useCurrentLocAsInitialXY==True:
		self.__initialX=self.__controller.getX()
		self.__initialY=self.__controller.getY()
	    str='Start point for crosstrack calculations is X=%s, Y=%s' %(self.__initialX, self.__initialY)
            pub.publish(str)
            rospy.loginfo(str)
	    
	    str='Initial Location is X=%s, Y=%s' %(self.__controller.getX(), self.__controller.getY())
            pub.publish(str)
            rospy.loginfo(str)
	    

            x = self.__X - self.__controller.getX()
            y = self.__Y - self.__controller.getY()          
            distance = (x**2 + y**2)**0.5
            str = "Distance to Waypoint %s" %distance
            pub.publish(str)
            rospy.loginfo(str)
            
            
            ##### Main loop #####
            while (time.time()-time_zero < self.__timeout) and self.__controller.getBackSeatErrorFlag() == 0:
                loop_time_zero = time.time()
                
                [heading, prop] = self.calc_route()
                self.__controller.setHeading(heading)
                self.__controller.setRearProp(prop)
                
                at_Z  = self.check_Z()
                at_XY = self.check_XY()
                
                if (at_XY == True) and (at_Z == True):
                    str = 'WayPoint Reached'
                    pub.publish(str)
                    return 'succeeded'
                
                dt = time.time() - loop_time_zero
                
                while dt < 1.0:
                    dt = time.time() - loop_time_zero

                
            ##### Main loop #####

            if self.__controller.getBackSeatErrorFlag() == 1:
		rospy.logerr("BackSeatDriver Identified Fault") 
                str = 'Backseat Driver Identified Fault GoToXYX preempted'
                pub.publish(str)

                return 'preempted'
            else:
		rospy.logerr("Go To Waypoint Timed Out")  
                str='GoToXYZ timed out, state aborted'              
		return 'aborted'  
		
    def crossTrackError(self,Wsx,Wsy,Wtx,Wty,Ax,Ay): #Returns crosstrack error of vehicle at point (Ax,Ay) from desired path from (Wsx,Wsy) to (Wtx,Wty)
	#Code from "A Robust Control Algorithm for Path Tracking by an Oceanographic Unmanned Aeronautical Vehicle" Bennett et al. 2007
	a=(Wsx-Wtx)**2
	b=(Wsy-Wty)**2
	c=math.sqrt(a+b)
	l0=(Wsy-Wty)/c
	l1=(Wsx-Wtx)/c
	l2=-l0*Wsx-l1*Wsy
	#l3=l1*Wtx-l0*Wty
	alpha=l0*Ax+l1*Ay+l2
	return alpha
            
    def check_Z(self):                
            
            if (abs(self.__controller.getDepth() - self.__Z) >= self.__Ztolerance):
                self.__at_Z_time = time.time()
                
            if time.time()-self.__at_Z_time > self.__Zstable_time:
                return True
            else:
                return False 
            
    def check_XY(self):                
            
            if (abs(self.__controller.getX() - self.__X) >= self.__XYtolerance) or (abs(self.__controller.getY() - self.__Y) >= self.__XYtolerance):
                self.__at_XY_time = time.time()
                
            if time.time()-self.__at_XY_time > self.__XYstable_time:
                return True
            else:
                return False 
    
    def calc_route(self):                
            
            x = self.__X - self.__controller.getX()
            y = self.__Y - self.__controller.getY()
            print 'x = ',x
            print 'y = ',y
            
            distance = (x**2 + y**2)**0.5
            str = "Distance to Waypoint %s" %distance
            rospy.loginfo(str)
            
            if (x >= 0) and (y >= 0):
                heading = numpy.degrees(numpy.arctan(x/y))
            if (x >= 0) and (y <= 0):
                heading = numpy.degrees(numpy.arctan(-y/x))+90
            if (x <= 0) and (y <= 0):
                heading = numpy.degrees(numpy.arctan(x/y))+180
            if (x <= 0) and (y >= 0):
                heading = numpy.degrees(numpy.arctan(y/-x))+270
                
           # if distance >= 5:
            #    heading = heading
             #   prop = (distance * 2)
                
           # if distance < 5:
            #    heading = heading
             #   prop = (distance * 1)
            
           # if (distance < 3) and (self.__controller.getHeading() - heading > 120):
            #    heading = heading + 180
             #   prop = (distance * -1)
                
           # if prop > 24:
            #    prop = 24
            #if prop < -10:
             #   prop = -10

	    demand = (heading)%360

    	    error  = demand - self.__controller.getHeading()
    
	    if error <-180:
		error =   error%360
	    if error > 180:
		error= -(-error%360)
                
	    if (abs(error) > 90):
		heading = heading
		prop = 0

	    if (abs(error) < 90):
		heading = heading
		prop = 12

	    if (abs(error) < 20) and (distance > 20):
		heading = heading
		prop = 15

            return [heading, prop]
            
                
