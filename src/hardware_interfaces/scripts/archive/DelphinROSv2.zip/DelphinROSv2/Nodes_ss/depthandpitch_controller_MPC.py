#!/usr/bin/python
import roslib; roslib.load_manifest('DelphinROSv2')
import rospy
import serial
import time
import numpy as np
import scipy 
from scipy import linalg
from math  import *

from DelphinROSv2.msg import tsl_setpoints
from DelphinROSv2.msg import tail_setpoints
from DelphinROSv2.msg import position
from DelphinROSv2.msg import compass
from DelphinROSv2.msg import depth_MPC
from DelphinROSv2.msg import pitch_MPC
from std_msgs.msg import Float32
from std_msgs.msg import Bool

#### DEFINE GLOBAL VARIABLES ####
global compass

################################################################################
#### CONTROLLER PARAMETERS #####################################################
################################################################################

def set_params():
    global M
    global gammad
    global gammap
    global DC
    global DM
    global PM
    global iter

    #### MODEL VALUES ####
    DC.buoyancy = 6.067
    DC.Ltf = 0.55
    DC.Ltr = 0.49
    DC.mdepth = 167.5
    DC.kdepth = 35  #51.12
    PC.Ipitch = 70
    PC.kpitch = 4.0477
    PC.Gpitch = 0.1461
    #####################

    #### CONTROLLER VALUES ####
    iter = 20
            
    DC.gain_rw =  0.01
    DC.Np = 50
    DC.Nc = 3
    DC.delta_t = 0.1
    
    PC.gain_rw =  0.1
    PC.Np = 50
    PC.Nc = 3
    PC.delta_t = 0.1
    #####################
    
    #### CONSTRAINTS ####
    DC.dtMax   =  3
    DC.dtMin   = -3
    DC.Tmax    =  6
    DC.Tmin    = -6
    DC.Thrust_Smin = 0
    DC.Thrust_Smax = 2000
    
    PC.dtMax   =  0.5
    PC.dtMin   = -0.5
    PC.Tmax    =  2
    PC.Tmin    = -2
    PC.Thrust_Smin = 0
    PC.Thrust_Smax = 2000
    #####################
    
    #### DEPTH MODEL ####
    Ac_depth = np.matrix([[0, 1],[0, (-DC.kdepth/DC.mdepth)]])
    Bc_depth = np.matrix([[0],[1]])
    Cc_depth = np.matrix([(1.0/DC.mdepth), 0])
    Dc_depth = np.matrix([0])
    SYS_depth = tuple([Ac_depth, Bc_depth, Cc_depth, Dc_depth])
    [Ad_depth, Bd_depth, Cd_depth, Dd_depth] = cont2discrete(SYS_depth,DC.delta_t)
    DM = tuple([Ad_depth, Bd_depth, Cd_depth, Dd_depth])
    #####################
    
    #### PITCH MODEL ####
    Ac_pitch = np.matrix([[0, 1],[(-180*PC.Gpitch/(PC.Ipitch*pi)), (-PC.kpitch/PC.Ipitch)]])
    Bc_pitch = np.matrix([[0],[1]])
    Cc_pitch = np.matrix([(180.0/(pi*PC.Ipitch)), 0])
    Dc_pitch = np.matrix([0])
    SYS_pitch = tuple([Ac_pitch, Bc_pitch, Cc_pitch, Dc_pitch])
    [Ad_pitch, Bd_pitch, Cd_pitch, Dd_pitch] = cont2discrete(SYS_pitch,PC.delta_t)
    PM = tuple([Ad_pitch, Bd_pitch, Cd_pitch, Dd_pitch])
    #####################
    
    #### CONSTRAINTS ####
    #Constraint on all delta_u terms
    M = np.matrix('1 0 0; 0 1 0; 0 0 1; -1 0 0; 0 -1 0; 0 0 -1; 1 0 0; 1 1 0; 1 1 1; -1 0 0; -1 -1 0; -1 -1 -1')
    gammad = np.transpose(np.matrix([DC.dtMax, DC.dtMax, DC.dtMax, -DC.dtMin, -DC.dtMin, -DC.dtMin, DC.Tmax, DC.Tmax, DC.Tmax, -DC.Tmin, -DC.Tmin, -DC.Tmin]))
    gammap = np.transpose(np.matrix([PC.dtMax, PC.dtMax, PC.dtMax, -PC.dtMin, -PC.dtMin, -PC.dtMin, PC.Tmax, PC.Tmax, PC.Tmax, -PC.Tmin, -PC.Tmin, -PC.Tmin]))

    #Constraint on first delta_u term only
    #M = np.matrix('1 0 0;-1 0 0; 1 0 0; -1 0 0')
    #gamma0 = np.transpose(np.matrix([DC.dtMax, -DC.dtMin, DC.Tmax, -DC.Tmin]))
    #####################

################################################################################
########## MAIN CONTROL LOOP ###################################################
################################################################################

def main_control_loop():

    #### SETUP ####
    global compass
    global DC
    global PC
    
    DC               = depth_MPC()
    PC               = pitch_MPC()
    PC.pitch_demand  = DC.pitch_demand = 0.0
    PC.depth_demand  = DC.depth_demand = 0.0
    speed            = 0.0
    compass          = compass()
    PC.onOFF         = False
    
    set_params()
    [Ad_depth, Bd_depth, Cd_depth, Dd_depth] = DM
    [Ad_pitch, Bd_pitch, Cd_pitch, Dd_pitch] = PM
    
    [dPhi_Phi, dPhi_F, dPhi_R, dA_e, dB_e, dC_e] = mpc_gain(DC.Np, DC.Nc, Ad_depth, Bd_depth, Cd_depth, Dd_depth)
    [pPhi_Phi, pPhi_F, pPhi_R, pA_e, pB_e, pC_e] = mpc_gain(PC.Np, PC.Nc, Ad_pitch, Bd_pitch, Cd_pitch, Dd_pitch)
    time_zero        = time.time()
    
    [n,n_in] = np.shape(dB_e)
    dxm = np.zeros([2,1],float)
    dXf = np.zeros([n,1],float)
    
    pxm = np.zeros([2,1],float)
    pXf = np.zeros([n,1],float)
    
    DC.u = 0
    PC.u = 0
    km = 99
    
################################################################################        
    while not rospy.is_shutdown():
        dt = time.time() - time_zero
        

        if dt >= DC.delta_t and DC.onOFF == True:
            time_zero = time.time()            
            calc_time_zero = time.time()

            ### Depth controller ###############################################
            dE = dPhi_Phi + np.dot(DC.gain_rw,np.eye(DC.Nc,DC.Nc))
            dF = -(np.dot(dPhi_R,DC.depth_demand) - np.dot(dPhi_F,dXf))            
            gamma = gammad + np.transpose(np.matrix([0, 0, 0, 0, 0, 0, -DC.u, -DC.u, -DC.u, DC.u, DC.u, DC.u])) #np.transpose(np.matrix([0, 0, -DC.u, DC.u]))
            
            [Delta_u, km] = QPhild(dE,dF,M,gamma,5)
            DC.km = km
            DC.deltau = Delta_u[0,0]
            DC.u = DC.u + DC.deltau
            dxm_old = dxm
            dxm = np.dot(Ad_depth,dxm) + np.dot(Bd_depth,DC.u)
            
            dXf[0:n-1] = dxm - dxm_old
            dXf[n-1:n] = DC.depth = PC.depth = compass.depth
            
            print 'depth demand = ',DC.depth_demand
            print 'delta_u = ',DC.deltau
            print 'u ', DC.u
            ####################################################################

            ### Pitch controller ###############################################
            if PC.onOFF == True:
                pE = pPhi_Phi + np.dot(PC.gain_rw,np.eye(PC.Nc,PC.Nc))
                pF = -(np.dot(pPhi_R,PC.pitch_demand) - np.dot(pPhi_F,pXf))
                
                gamma = gammap + np.transpose(np.matrix([0, 0, 0, 0, 0, 0, -PC.u, -PC.u, -PC.u, PC.u, PC.u, PC.u]))
                
                [Delta_u, km] = QPhild(pE,pF,M,gamma,5)
                PC.km = km
                PC.deltau = Delta_u[0,0]
                PC.u = PC.u + PC.deltau
                
                pxm_old = pxm
                pxm = np.dot(Ad_pitch,pxm) + np.dot(Bd_pitch,PC.u)
                
                pXf[0:n-1] = pxm - pxm_old
                pXf[n-1:n] = DC.pitch = PC.pitch = compass.pitch
            ###################################################################
                        
            ### Combine controller values ######################################       
            DC.thrust_total = DC.buoyancy + DC.u
            
            if PC.onOFF == True:
                print 'PC.onOFF = ',PC.onOFF
                thruster0 = DC.thrust_total*DC.Ltr/(DC.Ltf+DC.Ltr) - PC.u/(2) 
                thruster1 = DC.thrust_total*DC.Ltf/(DC.Ltf+DC.Ltr) + PC.u/(2) 
            else:
                print 'PC.onOFF = ',PC.onOFF
                thruster0 = 0.96*DC.thrust_total*DC.Ltr/(DC.Ltf+DC.Ltr) 
                thruster1 = 1.0417*DC.thrust_total*DC.Ltf/(DC.Ltf+DC.Ltr) 
            
            DC.thruster0 = PC.thruster0 =  int(limits((1.13*np.sign(DC.thrust_total)*(60*(np.abs(0.96*thruster0)/(1000*0.46*0.07**4))**0.5)), DC.Thrust_Smin, DC.Thrust_Smax))
            DC.thruster1 = PC.thruster1 =  int(limits((1.13*np.sign(DC.thrust_total)*(60*(np.abs(1.0417*thruster1)/(1000*0.46*0.07**4))**0.5)), DC.Thrust_Smin, DC.Thrust_Smax))
            ####################################################################
            
            ####################################################################
            DC.calc_time = PC.calc_time = time.time() - calc_time_zero
            ####################################################################
            print 'thruster 0 = ',thruster0
            print 'thruster 1 = ',thruster1
            ### Publish values #################################################
            pub_tsl.publish(thruster0 = DC.thruster0, thruster1 = DC.thruster1)
            pub_DC.publish(DC)
            pub_PC.publish(PC)
            ####################################################################
            
                        
######## END OF LOW LEVEL CONTROLLER ###########################################
################################################################################
################################################################################

################################################################################
################################################################################
def QPhild(E,F,M,gamma,iter_here):
    
    km = 0
    [n1,m1] = np.shape(M)
    eta = -np.dot(np.linalg.inv(E),F) 
    
    kk = 0
    i = 0
   
    while i < n1:
        if np.dot(M[i,:],eta) > gamma[i]:
            kk = kk + 1
            i = i + 1
        else:
            kk = kk + 0
            i = i + 1
            
    H = np.dot(M,(np.dot(np.linalg.inv(E),np.transpose(M))))
    K = np.dot(M,(np.dot(np.linalg.inv(E),F))) + gamma
    
    [n,m] = np.shape(K)
    
    Lambda =  np.zeros([n,m],float)
    Lambda_p = np.zeros([n,m],float)
    x = np.zeros([n,m],float)
    al = 10
    print 'Lambda0 = ',Lambda
    while km < iter:

        Lambda_p[:,0] =  Lambda[:,0]        
        i = 0
        while i < n:
            w = np.dot(H[i,:],Lambda) - np.dot(H[i,i],Lambda[i,0])
            w = w + K[i,0]
            la = -w/H[i,i]
            Lambda[i,0] = np.max([0, la])        
            i = i + 1
        
        print 'out of loop'
        print 'Lambda = ', Lambda
        print 'Lambda_p = ',Lambda_p    
        al = np.dot(np.transpose(Lambda - Lambda_p),(Lambda - Lambda_p))
        
        km = km + 1
        
        print 'km = ',km
        print 'al = ',al
        if al < 10e-8:
            print 'breaking'
            break
    
    eta = -np.dot(np.linalg.inv(E),F) - np.dot(np.linalg.inv(E),(np.dot(np.transpose(M),Lambda))) 
    
    return [eta, km]
################################################################################
################################################################################

################################################################################
################################################################################
def mpc_gain(Np,Nc,Ad,Bd,Cd,Dd):
   
    [m1,n1]   = np.shape(Cd)
    [n1,n_in] = np.shape(Bd)
    
    A_e = np.eye(n1+m1,n1+m1)
    A_e[0:n1,0:n1] = Ad
    A_e[n1:n1+m1,0:n1] = np.dot(Cd,Ad)
        
    B_e = np.zeros([n1+m1,n_in],float)
    B_e[0:n1,:] = Bd;
    B_e[n1:n1+m1,:] = np.dot(Cd,Bd)
    
    C_e = np.zeros([m1,n1+m1],float)
    C_e[:,n1:n1+m1] = np.eye(m1,m1)

    n = n1+m1
    h = np.zeros([Np,n],float)
    F = np.zeros([Np,n],float)
    
    h[0,:] = C_e
    F[0,:] = np.dot(C_e,A_e)
    
    kk = 1
    while kk < Np:
        h[kk,:] = np.dot(h[kk-1,:],A_e)
        F[kk,:] = np.dot(F[kk-1,:],A_e)
        kk = kk+1
    
    v = np.dot(h,B_e)
    Phi = np.zeros([Np,Nc],float)
    Phi[:,0:1] = v

    i = 1
    while i < Nc:
        Phi[0:i,i] = np.zeros([1,i],float)
        Phi[i:Np,i] = v[0:Np-i,0]
        i = i + 1    
        
    BarRs = np.ones([Np,1],float)
    
    Phi_Phi = np.dot(np.transpose(Phi),Phi)
    Phi_F = np.dot(np.transpose(Phi),F)
    Phi_R = np.dot(np.transpose(Phi),BarRs)
    
    return [Phi_Phi, Phi_F, Phi_R, A_e, B_e, C_e]
################################################################################
################################################################################

################################################################################
################################################################################
def cont2discrete(sys, dt, method="zoh", alpha=None):
    
    if len(sys) == 4:
        a, b, c, d = sys
    else:
        raise ValueError("First argument must either be a tuple of 4 (ss) arrays.")
    
    if method == 'zoh':
        # Build an exponential matrix
        em_upper = np.hstack((a, b))

        # Need to stack zeros under the a and b matrices
        em_lower = np.hstack((np.zeros((b.shape[1], a.shape[0])),
                              np.zeros((b.shape[1], b.shape[1])) ))
        em = np.vstack((em_upper, em_lower))
        ms = linalg.expm(dt * em)

        # Dispose of the lower rows
        ms = ms[:a.shape[0], :]
        ad = ms[:, 0:a.shape[1]]
        bd = ms[:, a.shape[1]:]
        cd = c
        dd = d

    else:
        raise ValueError("Unknown transformation method '%s'" % method)

    return ad, bd, cd, dd

################################################################################
################################################################################

def limits(value, min, max):       #Function to contrain within defined limits
    if value < min:				   
       value = min
    elif value > max:
       value = max
    return value
    
################################################################################
################################################################################

def depth_demand_cb(depthd):
    global DC
    global PC
    PC.depth_demand = DC.depth_demand = depthd.data
    
def pitch_demand_cb(pitchd):
    global flag
    global DC
    global PC
    PC.pitch_demand = DC.pitch_demand = pitchd.data

def compass_cb(data):
    global flag
    global compass
    compass  = data 

def depth_onOff_cb(onOff):
    global DC
    DC.onOFF = onOff.data
    
def pitch_onOff_cb(onOff):
    global PC
    PC.onOFF = onOff.data

################################################################################
#### INITIALISATION ############################################################
################################################################################

if __name__ == '__main__':

    rospy.init_node('MPC_Depth_controller')
    
    global depth_onOff
    global pitch_onOff
    
    rospy.Subscriber('depth_demand', Float32, depth_demand_cb)
    rospy.Subscriber('pitch_demand', Float32, pitch_demand_cb)
    rospy.Subscriber('compass_out', compass, compass_cb)
    rospy.Subscriber('Depth_onOFF', Bool, depth_onOff_cb)
    rospy.Subscriber('Pitch_onOFF', Bool, pitch_onOff_cb)
    
    
    pub_tsl  = rospy.Publisher('TSL_setpoints_vertical', tsl_setpoints)
    pub_DC   = rospy.Publisher('Depth_MPC_values', depth_MPC)
    pub_PC   = rospy.Publisher('Pitch_MPC_values', pitch_MPC)
    
    rospy.loginfo("Depth controller online")

    main_control_loop()
