#!/usr/bin/python
import roslib
roslib.load_manifest('DelphinROSv2')
import rospy
import sys
import cv
import time
from opencv.highgui import *

global time_zero
global frame_rate

time_zero = time.time()
frame_rate = 20.0

cv.NamedWindow('cam0', cv.CV_WINDOW_AUTOSIZE)
cv.NamedWindow('cam1', cv.CV_WINDOW_AUTOSIZE)
camera_index = 0
capture0 = cv.CaptureFromCAM(0)
capture1 = cv.CaptureFromCAM(1)
camera0_video = cv.CreateVideoWriter('camera0.mpg', cv.CV_FOURCC('P','I','M','1'), frame_rate, (352,288), 1) 
camera1_video = cv.CreateVideoWriter('camera1.mpg', cv.CV_FOURCC('P','I','M','1'), frame_rate, (352,288), 1)

cv.SetCaptureProperty(capture0, CV_CAP_PROP_FRAME_WIDTH, 352)
cv.SetCaptureProperty(capture0, CV_CAP_PROP_FRAME_HEIGHT, 288)
cv.SetCaptureProperty(capture1, CV_CAP_PROP_FRAME_WIDTH, 352)
cv.SetCaptureProperty(capture1, CV_CAP_PROP_FRAME_HEIGHT, 288)

def record():
        
    time_zero = time.time()
    time_total = time.time()
    while True:
        dt = time.time() - time_zero
                
        while (dt >= 1/frame_rate):
            time_zero = time.time()
            cam0 = cv.QueryFrame(capture0)
            cam1 = cv.QueryFrame(capture1)

            cv.ShowImage('cam0', cam0)
            cv.ShowImage('cam1', cam1)
            
            cv.WriteFrame(camera0_video, cam0)
            cv.WriteFrame(camera1_video, cam1)
            print 'Time = ',time.time()-time_total
            
 

if __name__ == '__main__':
  
    record()
