#!/usr/bin/python
import roslib; roslib.load_manifest('DelphinROSv2')
import rospy
import csv
import time
import numpy
import os
from datetime import datetime

from DelphinROSv2.msg import compass
from DelphinROSv2.msg import tsl_setpoints
from DelphinROSv2.msg import tsl_feedback
from std_msgs.msg import Float32
from std_msgs.msg import Int8
from std_msgs.msg import String
from DelphinROSv2.msg import tail_setpoints
from DelphinROSv2.msg import tail_feedback
from DelphinROSv2.msg import position
from DelphinROSv2.msg import gps
from DelphinROSv2.msg import altitude
from DelphinROSv2.msg import sonar
from DelphinROSv2.msg import depthandspeed_MPC
from DelphinROSv2.msg import depthandpitch_MPC
from DelphinROSv2.msg import heading_MPC
from DelphinROSv2.msg import dead_reckoner
from DelphinROSv2.msg import heading_control
from DelphinROSv2.msg import camera_info
from DelphinROSv2.msg import sonar_data
from DelphinROSv2.msg import SMS
from DelphinROSv2.msg import gyro
from DelphinROSv2.msg import line_info_msg      #for Kantapon

from DelphinROSv2.msg import ForcesAndMoments	#Only temporary

global tempWriter
global tempFile
global compassWriter
global compassFile
global tslHorzWriter
global tslHorzFile
global tslHorz
global tslVertWriter
global tslVertFile
global tslVert
global tsl_feedback
global heading_demand
global depth_demand
global prop_demand
global tailFile
global tailWriter
global tail_sp
global positionFile
global positionWriter
global gpsFile
global altimeterFile
global sonarFile
global sonarWriter
global time_zero
global pathFile
global log_folder



##############################################################
def callback_line_info(line_data):
    stringtime = time.time()-time_zero
    lineList = [stringtime, line_data.line_stat, line_data.d, line_data.angle]

    with open('%s/lineLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(lineList)
        except ValueError:
            print 'writerow error'    

##############################################################

def callback_compass(compass_data):
    #outputs compass data to file: time, heading, roll, pitch, temperature, depth, m, mx, my, mz, a, ax, ay, az 
    stringtime = time.time()-time_zero
    compassList = [stringtime, compass_data.heading, compass_data.roll, compass_data.pitch, compass_data.temperature, compass_data.depth, compass_data.m, compass_data.mx, compass_data.my, compass_data.mz, compass_data.a, compass_data.ax, compass_data.ay, compass_data.az, compass_data.depth_filt, compass_data.depth_der, compass_data.pitch_filt, compass_data.pitch_der]

    with open('%s/compassLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(compassList)
        except ValueError:
            print 'writerow error'

##############################################################
#Modifying this one
def FandM_callback(data):

    stringtime = time.time()-time_zero
    List = [stringtime, data.ModelVelX,data.ModelZ,data.ModelVelZ,data.ModelPitch,data.ModelVelP,data.ModelDelta,data.FoilLift,data.FoilDrag, data.FoilMoment,data.HullLift,data.HullDrag,data.HullMomentDueToPitch,data.HullMomentDueToPitchVel,data.HullHeaveDueToZdot,data.RestoringMoment]

    with open('%s/ForceAndMomentLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(List)
        except ValueError:
            print 'writerow error'


##############################################################

def temp_callback(temp_data):
    #outputs temperature sensor data to file
    stringtime = time.time()-time_zero
    tempList = [stringtime, temp_data.data]

    with open('%s/tempLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(tempList)
        except ValueError:
            print 'writerow error'
            
##############################################################
        
def tsl_feedback_callback(data):
    
    stringtime = time.time()-time_zero
    tslList = [stringtime, data.setpoint0, data.setpoint1, data.setpoint2, data.setpoint3, data.speed0, data.speed1, data.speed2, data.speed3, data.current0, data.current1, data.current2, data.current3, data.voltage]
    
    with open('%s/tslLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(tslList)
        except ValueError:
            print 'writerow error'
            
##############################################################
            
def tail_feedback_callback(data):

    stringtime = time.time()-time_zero
    tailList = [stringtime, data.bsp, data.b, data.csp, data.c, data.dsp, data.d, data.esp, data.e, prop_demand, data.current, data.rpm]
        
    with open('%s/tailLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(tailList)
        except ValueError:
            print 'writerow error'

##############################################################

def headingdemand_callback(data):
    #updates heading_demand - to be included in horizontal thruster log file
    global heading_demand
    heading_demand = data.data
        
def depthdemand_callback(data):
    #updates depth_demand - to be included in vertical thruster log file
    global depth_demand
    depth_demand = data.data

def propdemand_callback(data):
    #updates prop_demand - to be included in tail section log file
    global prop_demand
    prop_demand = data.data
    
##############################################################

def position_callback(position):
    
    stringtime = time.time()-time_zero
    positionList = [stringtime, position.X, position.Y, position.Z, position.forward_vel, position.sway_vel, position.lat, position.long, position.altitude, position.ValidGPSfix]
    
    with open('%s/positionLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(positionList)
        except ValueError:
            print 'writerow error'

##############################################################

def mission_callback(HC): 
    stringtime = time.time()-time_zero
    missionList = [stringtime, HC.data]
    
    with open('%s/mission.txt' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(missionList)
        except ValueError:
            print 'writerow error'

##############################################################

def gps_callback(gps):
    stringtime = time.time()-time_zero
    gpsList = [stringtime, gps.latitude, gps.longitude, gps.time, gps.number_of_satelites, gps.fix,gps.speed,gps.x,gps.y]  
    
    with open('%s/gpsLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(gpsList)
        except ValueError:
            print 'writerow error'

##############################################################

def altimeter_callback(altimeter):
    stringtime = time.time()-time_zero
    altimeterList=[stringtime, altimeter.altitude, altimeter.altitude_filt, altimeter.altitude_der]
    
    with open('%s/altimeterLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(altimeterList)
        except ValueError:
            print 'writerow error'

##############################################################

def sonar_callback(sonar): ## Problem with logging raw data

    try:
        stringtime = time.time()-time_zero
        
        raw = list(numpy.fromstring(sonar.rawData, dtype = numpy.uint8))
                
        sonarData = [stringtime, sonar.transBearing, sonar.pitch, sonar.TargetRange, sonar.meanIntinsity ,raw]
        
        with open('%s/sonarLogwithRaw.csv' %(dirname), "a") as f:
            try:
                Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                Writer.writerow(sonarData)
            except ValueError:
                print 'writerow error'
        
        sonarData = [stringtime, sonar.transBearing, sonar.pitch, sonar.TargetRange, sonar.meanIntinsity]
        with open('%s/sonarLog.csv' %(dirname), "a") as f:
            try:
                Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                Writer.writerow(sonarData)
            except ValueError:
                print 'writerow error'
                
    except ValueError:
        print 'Problem with sonar logger!!!'
##############################################################
        
def headingMPC_callback(data): 
    stringtime = time.time()-time_zero
    
    if data.onOFF == True:
        data.onOFF = 1
    else:
        data.onOFF = 0
        
    headingMPCList = [stringtime, data.onOFF, data.heading, data.heading_demand, data.error, data.speed, data.ddelta, data.delta, data.dT2, data.dT3, data.T2, data.T3, data.thruster2, data.thruster3, data.delta_gain, data.thruster_gain, data.thruster_penalty, data.Np, data.Nc, data.delta_t, data.calc_time, data.km]
    
    with open('%s/headingMPCLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(headingMPCList)
        except ValueError:
            print 'writerow error'


##############################################################

def depthandspeedMPC_callback(C): 
    stringtime = time.time()-time_zero
    
    if C.onOFF == True:
        C.onOFF = 1
    else:
        C.onOFF = 0
        
    depthandspeedMPCList = [stringtime, C.onOFF, C.depth, C.depth_demand, C.pitch, C.speed, C.speed_demand, C.prop, C.dprop, C.ddelta, C.delta, C.dT0, C.T0, C.T1, C.thruster0, C.thruster1, C.prop_gain, C.delta_gain, C.thruster_gain, C.Np, C.Nc, C.delta_t, C.calc_time, C.km, C.sim_time, C.Xf1, C.Xf2, C.Xf3, C.Xf4, C.Xf5, C.Xf6, C.Xf7, C.Xf8]
    
    with open('%s/depthandspeedMPCLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(depthandspeedMPCList)
        except ValueError:
            print 'writerow error'
            
##############################################################
        
def reckoner_callback(data): 
    global KMLtime
    global reckonertime
    stringtime = time.time()-time_zero
        
    reckonerList = [stringtime, data.X ,data.Y ,data.Z ,data.distance ,data.heading ,data.pitch ,data.roll ,data.velX ,data.velY ,data.velZ ,data.velP ,data.velH ,data.latitude ,data.longitude ,data.altitude ,data.ValidGPSfix, data.X_dead, data.Y_dead, data.velX_dead, data.velY_dead, data.temperature, data.frame0,data.frame1, data.velP_dead] 
    
    if time.time() - reckonertime >= 0.2:
        with open('%s/reckonerLog.csv' %(dirname), "a") as f:
            try:
                Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                Writer.writerow(reckonerList)
            except ValueError:
                print 'writerow error'
        reckonertime = time.time()
            
    #Update KML file every 5s
    if time.time()-KMLtime>5:
        pathLine = '%.32f,%.32f,5 \n' %(data.latitude, data.longitude)
        
        with open('%s/path.kml' %(dirname), "a") as f:
            try:
                f.write(pathLine)
            except ValueError:
                print 'writerow error'
	
        KMLtime=time.time()
        
##############################################################

def headingPID_callback(data): 
    stringtime = time.time()-time_zero
        
    headingPIDList = [stringtime, data.heading, data.speed, data.heading_demand, data.sway, data.error, data.int_error, data.der_error, data.aft_deadzone, data.fwd_deadzone, data.min_int_error, data.max_int_error, data.CS_Pgain, data.CS_min , data.CS_max , data.CS_Pterm, data.CSt, data.CSb, data.Thrust_Pgain, data.Thrust_Igain, data.Thrust_Dgain, data.Thrust_Pmin, data.Thrust_Pmax, data.Thrust_Imin, data.Thrust_Imax, data.Thrust_Dmin, data.Thrust_Dmax, data.Thrust_Smin, data.Thrust_Smax  , data.Thrust_Pterm, data.Thrust_Iterm, data.Thrust_Dterm, data.Thrust_heading, data.Thrust_sway_min, data.Thrust_sway_max, data.thruster0, data.thruster1]
    
    with open('%s/headingPIDLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(headingPIDList)
        except ValueError:
            print 'writerow error'
            
##############################################################
            
def camera_callback(data): 
    stringtime = time.time()-time_zero
    #print 'Camera data!!!!'
        
    camera_info_List = [stringtime, data.cam0, data.cam1, data.cam0frame, data.cam1frame, data.cam0size, data.cam1size, data.latitude, data.longitude, data.depth, data.altitude, data.speed, data.heading]
    
    with open('%s/camera_infoLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(camera_info_List)
        except ValueError:
            print 'writerow error'
            
##############################################################
            
def SMS_callback(data): 
    stringtime = time.time()-time_zero
    #print 'Camera data!!!!'
        
    sms_info_List = [stringtime, data.signal, data.depth, data.latitude, data.longitude]
    
    with open('%s/sms_infoLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(sms_info_List)
        except ValueError:
            print 'writerow error'

##############################################################
            
def gyro_callback(data): 
    stringtime = time.time()-time_zero
        
    rate_gyro_List = [stringtime, data.raw, data.rate, data.temp]
#    print rate_gyro_List
    
    with open('%s/rate_gyroLog.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(rate_gyro_List)
        except ValueError:
            print 'writerow error'

##############################################################
            
def depthandpitchMPC_callback(data): 
    stringtime = time.time()-time_zero
    
    if data.onOFF == True:
        data.onOFF = 1
    else:
        data.onOFF = 0
        
    depthandpitchMPC_List = [stringtime, data.onOFF, data.depth, data.depth_demand, data.pitch, data.pitch_demand, data.dT0, data.dT1, data.T0, data.T1, data.thruster0, data.thruster1, data.gain, data.Np, data.Nc, data.delta_t, data.calc_time, data.km, data.xf1, data.xf2, data.xf3, data.xf4, data.xf5, data.xf6]
    
    with open('%s/depthandpitchMPC_Log.csv' %(dirname), "a") as f:
        try:
            Writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            Writer.writerow(depthandpitchMPC_List)
        except ValueError:
            print 'writerow error'

            

##############################################################

def shutdown():
    #shutdown behaviour - close all files
    #print 'shutting down'
    with open('%s/path.kml' %(dirname), "a") as f:
        try:  
            f.write('</coordinates>\n </LineString>\n </Placemark>\n </kml>\n')
        except ValueError:
            print 'write error'

################################################################################
####### INITIALISE #############################################################
################################################################################

if __name__ == '__main__':
    rospy.init_node('Logger')
    
    stringtime = datetime.now()
    stringtime = stringtime.strftime('%Y-%m-%d_%H-%M-%S')
    rospy.loginfo('Logger started at %s.'%(stringtime))
    pub_folder = rospy.Publisher('folder', String)
    pub_vidfolder = rospy.Publisher('vidfolder', String)
    
    global heading_demand
    global depth_demand
    global prop_demand
    global tail_horizontal_setpoints
    global tail_vertical_setpoints
    global tsl_Vert
    global tsl_Horz
    global time_zero
    global KMLtime
    global lat_orig
    global long_orig
    
    heading_demand = -1
    depth_demand   = -1
    prop_demand    = -1
    tail_horizontal_setpoints = tail_setpoints()
    tail_vertical_setpoints   = tail_setpoints()
    tsl_Vert  = tsl_setpoints()
    tsl_Horz  = tsl_setpoints()
    time_zero = time.time()
    KMLtime   = time.time()
    reckonertime = time.time()
    
    try:
        lat_orig  = rospy.get_param('lat_orig')
        long_orig = rospy.get_param('long_orig')
    except:
        lat_orig  = 0
        long_orig = 0
  
################################################################################
######## FOLDERS ###############################################################
################################################################################
  
    #define files and writers
    logfolder =  'logFiles'   
    dirname   = logfolder + '/' + stringtime
    vidfolder = dirname + '/' + 'videos'
    
    if not os.path.isdir(logfolder):
        print 'made logfolder'
        os.mkdir(logfolder)
    if not os.path.isdir(dirname):
        print 'made test folder'
        os.mkdir(dirname)
    if not os.path.isdir(vidfolder):
        print 'made video folder'
        os.mkdir(vidfolder)
        
    time.sleep(5)
    pub_folder.publish(dirname)
    pub_vidfolder.publish(vidfolder)
    
################################################################################
######## KML POSITION HEADER ###################################################
################################################################################

    with open('%s/path.kml' %(dirname), "a") as f:
            try:  
                f.write('<?xml version=\'1.0\' encoding=\'UTF-8\'?>\n')
                f.write('<kml xmlns=\'http://earth.google.com/kml/2.0\'><Placemark>\n')
                f.write('<description>Route generated by Delphin2</description>\n')
                f.write('<name>Delphin2 Path</name>\n')
                f.write('<LookAt>\n')
                str = '<longitude>%s</longitude>\n' %long_orig
                f.write(str) 
                str = '<latitude>%s</latitude>\n' %lat_orig
                f.write(str) 
                f.write('<range>400</range>\n')
                f.write('<tilt>25</tilt>\n')
                f.write('<heading>-5</heading>\n')
                f.write('</LookAt><visibility>1</visibility>\n')
                f.write('<open>0</open>\n')
                f.write('<Style>\n')
                f.write('<LineStyle>\n')
                f.write('<color>7f0000ff</color>\n')
                f.write('<width>4</width>\n')
                f.write('</LineStyle>\n')
                f.write('</Style>\n')
                f.write('<LineString>\n')
                f.write('<altitudeMode>relativeToGround</altitudeMode>\n')
                f.write('<coordinates>\n')
            except ValueError:
                print 'write error'

################################################################################
######## SUBSCRIBERS ###########################################################
################################################################################

    rospy.Subscriber('compass_out', compass, callback_compass)
    rospy.Subscriber('TSL_feedback', tsl_feedback, tsl_feedback_callback)        
    rospy.Subscriber('heading_demand', Float32, headingdemand_callback)
    rospy.Subscriber('depth_demand', Float32, depthdemand_callback)
    rospy.Subscriber('prop_demand', Int8, propdemand_callback)
    rospy.Subscriber('tail_output', tail_feedback, tail_feedback_callback)
    #rospy.Subscriber('position_dead', position, position_callback)
    rospy.Subscriber('gps_out', gps, gps_callback)
    rospy.Subscriber('altimeter_out',altitude, altimeter_callback)
    #rospy.Subscriber('sonar_processed', sonar_data, sonar_callback)
    
    
    rospy.Subscriber('MissionStrings', String, mission_callback)
    rospy.Subscriber('DepthandSpeed_MPC_values', depthandspeed_MPC, depthandspeedMPC_callback)
    rospy.Subscriber('Heading_MPC_values', heading_MPC, headingMPC_callback)
    rospy.Subscriber('DepthandPitch_MPC_values', depthandpitch_MPC, depthandpitchMPC_callback)
    rospy.Subscriber('dead_reckoner', dead_reckoner, reckoner_callback) 
    rospy.Subscriber('Heading_controller_values', heading_control, headingPID_callback)
    
    rospy.Subscriber('camera_info', camera_info, camera_callback)
    rospy.Subscriber('SMS_info', SMS, SMS_callback)
    rospy.Subscriber('water_temp', Float32, temp_callback)
    rospy.Subscriber('Model_ForcesAndMoments',ForcesAndMoments, FandM_callback)
    rospy.Subscriber('line_info', line_info_msg, callback_line_info)     #For Kantapon   
    rospy.Subscriber('rate_gyro', gyro, gyro_callback)    

    str = "Logger online - output directory: %s" %(dirname)
    rospy.loginfo(str)
    
    rospy.on_shutdown(shutdown)

    rospy.spin()
    
