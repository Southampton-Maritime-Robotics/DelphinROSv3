#!/usr/bin/python
import roslib; roslib.load_manifest('DelphinROSv2')
import rospy
import serial
import time
import numpy as np
import csv
import string
from DelphinROSv2.msg import gyro


def readData():
    
    vScale    = 5.0/2**24                                                   # 5V / 24 bit resolution
    degScale  = 0.02                                                     # 20mV/^o/s
    zero      = -86034269.2345679
    rate      = 0.0
    heading   = 0.0
    stringtime= 0.0
    time_zero = time.time()
    first     = True
    
    
    while not rospy.is_shutdown():  
        
        t = time.time()
        
        dataRaw = serialPort.readline(size = None, eol = '\n')
        #print dataRaw
        stringtime_old = stringtime
        stringtime     = time.time()-time_zero
        
        try:
            split_data = string.split(dataRaw,',')		 
            x = np.shape(split_data)

            if x[0] == 2:
                
                rate_old = rate                
                data     = float(split_data[0])
                temp     = float(split_data[1])
                
                data2    = data - zero
                voltage  = data2*vScale
                rate     = -voltage*degScale*10 #Minus because its mounted upside down!
                
                print 'Rate = ',rate
                print 'Temp raw = ',temp
                
                pub.publish(raw = data, rate = rate, temp = temp)
                
                
            else:
                first = False
                    

        except ValueError:
            pass
        

################################################################
def setUpSerial(): # set up the serial port
    global serialPort
    serialPort = serial.Serial(port='/dev/usbGyro', baudrate='9600', timeout=0.5)
    serialPort.bytesize = serial.EIGHTBITS
    serialPort.stopbits = serial.STOPBITS_ONE
    serialPort.parity = serial.PARITY_NONE

    return serialPort.isOpen()

################################################################
def shutdown():
    serialPort.flushInput()
    serialPort.flushOutput()
    serialPort.close()

        
################################################################        
#     INITIALISE     ###########################################
################################################################
if __name__ == '__main__':
   
    rospy.init_node('Rate_gyro')
    rospy.on_shutdown(shutdown)         #Defining shutdown behaviour  

    pub = rospy.Publisher('rate_gyro', gyro)
    
    port_status = setUpSerial()
    serialPort.flushInput()
    
    str = "Rate Gyro online" 
    rospy.loginfo(str)
    
    readData()
        
    
#        global pubStatus
    
