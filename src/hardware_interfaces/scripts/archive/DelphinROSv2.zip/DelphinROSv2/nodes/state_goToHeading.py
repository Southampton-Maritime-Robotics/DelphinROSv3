#!/usr/bin/env python

import roslib; roslib.load_manifest('DelphinROSv2')
import rospy
import smach
import smach_ros
import time


class GoToHeading(smach.State):
    def __init__(self, lib, demand, tolerance, stable_time, timeout):
            smach.State.__init__(self, outcomes=['succeeded','aborted','preempted'])
            self.__controller = lib
            self.__demand = demand
            self.__tolerance = tolerance
            self.__stable_time = stable_time
            self.__timeout = timeout
            self.__at_heading_time = time.time()


    def execute(self,userdata):
            time_zero = time.time()
            at_heading = False
            
            self.__controller.setHeading(self.__demand)
            
            ##### Main loop #####
            while (time.time()-time_zero < self.__timeout) and self.__controller.getBackSeatErrorFlag() == 0:
                
                at_heading = self.check_heading()
                
                
                if at_heading == True:
                    return 'succeeded'
                
            ##### Main loop #####

            if self.__controller.getBackSeatErrorFlag() == 1:
                return 'preempted'
            else:
                return 'aborted'  
            
    def check_heading(self):                
            
            if (abs(self.__controller.getHeading() - self.__demand) >= self.__tolerance):
                self.__at_heading_time = time.time()
                
            if time.time()-self.__at_heading_time > self.__stable_time:
                return True
            else:
                return False
                