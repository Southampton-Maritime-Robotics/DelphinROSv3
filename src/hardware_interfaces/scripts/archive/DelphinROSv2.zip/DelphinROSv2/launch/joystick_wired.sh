#/bin/bash

ROS_IP=169.253.51.57
roslaunch DelphinROSv2 delphin_joystick.launch
