#/bin/bash

ROS_IP=169.254.51.57
roslaunch DelphinROS joystick_control.launch
