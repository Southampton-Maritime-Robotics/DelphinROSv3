#include <iostream>
#include <math.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include "ros/ros.h"
#include "linedetection/line_info_msg.h"
#include <sstream>

using namespace std;
using namespace cv;

const double PI = atan(1.0)*4;

double angle_cal( double x , double y ){

    double angle;

    if( x==0 ){

        angle = 90;

    }else{
        angle = atan(y/x)*180/PI;

        if( angle < 0 ){
            angle = 180 + angle;
        }

    }

    return angle;

}

double d_cal( double Q1x, double Q1y, double Q2x, double Q2y, double Px, double Py, double width, double height ){

    double d;
    double d_cor1,d_cor2;   //distance according to the top left and bottom right corner

        d = abs( (Q2x-Q1x)*(Q1y-Py) - (Q2y-Q1y)*(Q1x-Px) )
            / sqrt( pow( (double)(Q2x-Q1x),2 ) + pow( (double)(Q2y-Q1y),2 ) );

        d_cor1 = abs( (Q2x-Q1x)*(Q1y-0) - (Q2y-Q1y)*(Q1x-0) )
            / sqrt( pow( (double)(Q2x-Q1x),2 ) + pow( (double)(Q2y-Q1y),2 ) );
        d_cor2 = abs( (Q2x-Q1x)*(Q1y-height) - (Q2y-Q1y)*(Q1x-width) )
            / sqrt( pow( (double)(Q2x-Q1x),2 ) + pow( (double)(Q2y-Q1y),2 ) );

        if(d_cor1 < d_cor2){    //if the line is closer to the origin the distance will be negetive value
            d = -d;
        }

    return d;

}

int main( int argc, char** argv){

    //Open webcam
    VideoCapture cap(0);                                                    //'o' for integrated webcam, or '1' for external webcam
    if(!cap.isOpened()){                                                    // If an error occured...
        cout << "Error while opening Webcam.\n";
        return-1;                                                           // ... quit the application
    }
    cout << "Webcam opened successfully !\n";

    Mat frame;
    Mat frame_2;
    Mat imgHSV;
    Mat edges;
    namedWindow("video",1);
    namedWindow("video_2",1);
    namedWindow("HSV_space");
    namedWindow("edges_detection");

    unsigned int i,j,size=500;
    unsigned int intensity[size], intensity_main, group, group_max;

    int status;

    double length[size], length_ini;
    double x_com_ini, y_com_ini, x_mid_ini, y_mid_ini, d_ini, angle_ini, d_check;
    double x_mid[size], x_mid_main, y_mid[size], y_mid_main, x_com[size], x_com_main, y_com[size], y_com_main;
    double d[size], d_main, d_tor = 15/*in percent*/, angle[size], angle_main, angle_tor = 15/*in degree*/;
    double Px,Py;   //this group used to determine distance between point and line.
    double x0,y0,x1,y1;

    int yawing = 0, swaying = 0;

//
	Point org;
	stringstream sstm;
//
	stringstream ss;

	//preparation for ROS to publish line_info
	ros::init(argc, argv, "vector_base");
	ros::NodeHandle n;
	ros::Publisher vector_base_pub = n.advertise<linedetection::line_info_msg>("line_info", 1000);
	ros::Rate loop_rate(10);

    for(;;){
        //capture frame from streaming video
        cap >> frame;
	//frame = imread("main.png");
        if(!frame.data) break;

	Px= frame.cols/2;     //x component of middle point of frame
	Py= frame.rows/2;     //y component of middle point of frame

	//color selection
	cvtColor(frame,imgHSV, CV_RGB2HSV);
	imshow("HSV_space", imgHSV);  
	inRange(imgHSV, Scalar(110,120,120), Scalar(150,255,255), edges);  

        //detect edges from the captured frame and shown on window
//        blur(edges, edges, Size(3,3));
	Canny(edges, edges, 10, 30, 3);
        imshow("edges_detection", edges);

//
        frame.copyTo(frame_2);

        //detect lines from available edges
        vector<Vec4i> lines;            //line(x0,y0,x1,y1)
        HoughLinesP(	edges,			//source image to do line detection
				lines,			//line storage (x0, y0, x1, y1)
				1,				//the resolution of the parameter rho in pixels
				CV_PI/180,		//the rasolution of the parameter theta in radians
				80,				//threshold
				150,			//minLinLength; The minimum number of points that can form a line
				15 );			//maxLineGap; The maximum gap between two points to be considered in the same line

	status = 0;     //this parameter will be used to check if there are any lines or not. If there are no line detected, the plotting step will be skipped
	group_max = 0;
	intensity_main = 0;	//clear the intensity of main line form previous iteration
	    
	    
	//grouping
        for(i=0; i<lines.size(); i++){

		if(i == 0){     //define first reference group

			status = 1;
			group = 0;
			group_max = 1;
			intensity[group] = 1;

			//these are x and y component of directional vector of this line
			x_com[group] = lines[i][2] - lines[i][0];
			y_com[group] = lines[i][3] - lines[i][1];

			//check the direction of x and y component and correct them if necessary
			if( y_com[group] < 0){
				x_com[group] = 0-x_com[group];
				y_com[group] = 0-y_com[group];
			}

//
			length[group] = sqrt( pow(x_com[group],2) + pow(y_com[group],2) );

			x_mid[group] = (lines[i][2] + lines[i][0]) / 2;
			y_mid[group] = (lines[i][3] + lines[i][1]) / 2;

			//calculate the shortest distance between this lines group and mid frame point
			d[group] = d_cal(   	x_mid[group]+x_com[group]/2,      //x component of first end point
							y_mid[group]+y_com[group]/2,      //y component of first end point
							x_mid[group]-x_com[group]/2,      //x component of second end point
							y_mid[group]-y_com[group]/2,      //y component of second end point
							Px,Py,
							frame.cols,frame.rows
						);

			//calculate the inclination of this lines group based on horizontal line
			angle[group] = angle_cal( x_com[group], y_com[group] );
			
			//keep this first line as main line
			intensity_main = intensity[group];
			d_main = d[group];
			angle_main = angle[group];
			x_mid_main = x_mid[group];
			y_mid_main = y_mid[group];
			x_com_main = x_com[group];
			y_com_main = y_com[group];

		}else{          //if there are more than one line, start matching

			x_com_ini = lines[i][2] - lines[i][0];
			y_com_ini = lines[i][3] - lines[i][1];

			//check the direction of x and y component and correct them if necessary
			if( y_com_ini < 0 ){
				x_com_ini = 0-x_com_ini;
				y_com_ini = 0-y_com_ini;
			}
//
			length_ini = sqrt( pow(x_com_ini,2) + pow(y_com_ini,2) );

			x_mid_ini = ( lines[i][2] + lines[i][0] ) / 2;
			y_mid_ini = ( lines[i][3] + lines[i][1] ) / 2;

			//calculate the shortest distance between this line and mid frame point
			d_ini = d_cal(  	x_mid_ini+x_com_ini/2,      //x component of first end point
						y_mid_ini+y_com_ini/2,      //y component of first end point
						x_mid_ini-x_com_ini/2,      //x component of second end point
						y_mid_ini-y_com_ini/2,      //y component of second end point
						Px,Py,
						frame.cols,frame.rows
					);

			//calculate the inclination of this lines group based on horizontal line
			angle_ini = angle_cal( x_com_ini, y_com_ini );

			//matches line with available groups
			for( j = 0 ; j < group_max ; j++ ){
//////////
				d_check = d_cal(   	x_mid_ini+x_com_ini/2,      //x component of first end point
								y_mid_ini+y_com_ini/2,      //y component of first end point
								x_mid_ini-x_com_ini/2,      //x component of second end point
								y_mid_ini-y_com_ini/2,      //y component of second end point
								x_mid[j],y_mid[j],
								frame.cols,frame.rows
							);

				// if d and angle of i_th line close to j_th group, this line can be blend into such group
				if( (abs(d[j]-d_ini)/frame.cols*100 <= d_tor) && (abs( abs(angle[j])-abs(angle_ini) ) <= angle_tor) ){

					group = j;

					x_com[group] = ( x_com[group]*intensity[group] + x_com_ini ) / ( intensity[group] + 1 );
					y_com[group] = ( y_com[group]*intensity[group] + y_com_ini ) / ( intensity[group] + 1 );

					//check the direction of x and y component and correct them if necessary
					if( y_com[group] < 0){
						x_com[group] = 0-x_com[group];
						y_com[group] = 0-y_com[group];
					}
//
					length[group] = sqrt( pow(x_com[group],2) + pow(y_com[group],2) );

					x_mid[group] = ( x_mid[group]*intensity[group] + x_mid_ini ) / ( intensity[group] + 1 );
					y_mid[group] = ( y_mid[group]*intensity[group] + y_mid_ini ) / ( intensity[group] + 1 );


					//update the shortest distance between this line and mid frame point of this lines group
					d[group] = d_cal(  	x_mid[group]+x_com[group]/2,      //x component of first end point
									y_mid[group]+y_com[group]/2,      //y component of first end point
									x_mid[group]-x_com[group]/2,      //x component of second end point
									y_mid[group]-y_com[group]/2,      //y component of second end point
									Px,Py,
									frame.cols,frame.rows
						);

					//update the inclination of this lines group based on horizontal line
					angle_ini = angle_cal( x_com_ini, y_com_ini );

					intensity[group] = intensity[group] + 1;

					//if this line has higher intensity than the current main line, threat it as a new main line and delect the old main line.
					if( intensity[group] > intensity_main ){
						intensity_main = intensity[group];
						d_main = d[group];
						angle_main = angle[group];		
						x_mid_main = x_mid[group];
						y_mid_main = y_mid[group];
						x_com_main = x_com[group];
						y_com_main = y_com[group];			
					}

					break;

				}//end of inner criterias

			}//end of matcing

			if( j==group_max ){	//if this line cannot be match with any group, defines a now group

				group = j;
				group_max = group_max + 1;
				intensity[group] = 1;

				x_com[group] = lines[i][2] - lines[i][0];
				y_com[group] = lines[i][3] - lines[i][1];

				//check the direction of x and y component and correct them if necessary
				if( y_com[group] < 0 ){
					x_com[group] = 0-x_com[group];
					y_com[group] = 0-y_com[group];
				}

				length[group] = sqrt( pow(x_com[group],2) + pow(y_com[group],2) );

				x_mid[group]  = (lines[i][2] + lines[i][0]) / 2;
				y_mid[group] = (lines[i][3] + lines[i][1]) / 2;

				//calculate the shortest distance between this line and mid frame point
				d[group] = d_cal(   	x_mid[group]+x_com[group]/2,      //x component of first end point
								y_mid[group]+y_com[group]/2,      //y component of first end point
								x_mid[group]-x_com[group]/2,      //x component of second end point
								y_mid[group]-y_com[group]/2,      //y component of second end point
								Px,Py,
								frame.cols,frame.rows
							);

				//calculate the inclination of this lines group based on horizontal line
				angle[group] = angle_cal( x_com[group], y_com[group] );

				if( intensity[group] > intensity_main ){
					intensity_main = intensity[group];
					d_main = d[group];
					angle_main = angle[group];
					x_mid_main = x_mid[group];
					y_mid_main = y_mid[group];
					x_com_main = x_com[group];
					y_com_main = y_com[group];
				}

			}

		}

//
		line( frame_2, Point(lines[i][0],lines[i][1]), Point(lines[i][2],lines[i][3]), Scalar(0,0,255), 1, 8);

        }   //end of grouping 
	    
        
//		plot the lines directly resulting from HoughLineP
        imshow("video_2", frame_2);

//        clear value
        yawing = 1500;
        swaying = 1500;

		//plot a final result of lines detection
	if(status){
		for( i = 0 ; i < group_max + 1 ; i++ ){

			if( i < group_max ){	//plot all lines of each group

				x0 = x_mid[i] + 0.5*x_com[i];
				y0 = y_mid[i] + 0.5*y_com[i];
				x1 = x_mid[i] - 0.5*x_com[i];
				y1 = y_mid[i] - 0.5*y_com[i];

				line( frame, Point((int)x0,(int)y0), Point((int)x1,(int)y1), Scalar(0,255,0), 1, 8);

				//plot characteristics of all i_th line of each group
				sstm.str(""); //empty the old value of string stream
				sstm << "no" << i+1 << " i" << intensity[i] << " d" << (int)d[i] << " a" << (int)angle[i];
				org = Point((int)x_mid[i],(int)y_mid[i]);
				putText(frame,sstm.str(),org,FONT_HERSHEY_PLAIN,1.5,(0,0,255),2,8);			

			}else{		//plot main line

				x0 = x_mid_main + 0.5*x_com_main;
				y0 = y_mid_main + 0.5*y_com_main;
				x1 = x_mid_main - 0.5*x_com_main;
				y1 = y_mid_main - 0.5*y_com_main;

				line( frame, Point((int)x0,(int)y0), Point((int)x1,(int)y1), Scalar(0,0,255), 1, 8);
		
				//plot characteristics of main line
				sstm.str(""); //empty the old value of string stream
				sstm << "main";// << " i" << intensity_main << " d" << (int)d_main << " a" << (int)angle_main;
				org = Point((int)x_mid_main,(int)y_mid_main);
				putText(frame,sstm.str(),org,FONT_HERSHEY_PLAIN,1.5,(0,255,0),2,8);	
		
			}
		
		}

////////////////////////////////////////////////////////////////
								if( angle[0] >= (90+angle_tor/2) ){

									x0 = 90+angle_tor/2;
									x1 = 180;
									y0 = 1430;
									y1 = 1380;

									yawing = (int)( y0 + ( angle[0] - x0 ) * (y1-y0)/(x1-x0) );

								}else if( angle[0] <= (90-angle_tor/2) ){

									x0 = 90-angle_tor/2;
									x1 = 0;
									y0 = 1540;
									y1 = 1590;

									yawing = (int)( y0 + ( angle[0] - x0 ) * (y1-y0)/(x1-x0) );
								}

// should adjust swaying when the angle is between 90+-45
//should delete some horizontal line
//make this condition as continous control value
								if( d[0] >= (frame.rows*d_tor/200) ){

									x0 = frame.rows*d_tor/200;
									x1 = frame.rows/2;
									y0 = 1540;
									y1 = 1590;

									swaying = (int)( y0 + ( d[0] - x0 ) * (y1-y0)/(x1-x0) );

								}else if( d[0] <= (-frame.rows*d_tor/200) ){

									x0 = -frame.rows*d_tor/200;
									x1 = -frame.rows/2;
									y0 = 1430;
									y1 = 1380;

									swaying = (int)( y0 + ( d[0] - x0 ) * (y1-y0)/(x1-x0) );
								}

	}   // end of final result forming 

		//~ //plot a total number of line on the frame
			sstm.str(""); //empty the old value of string stream
			sstm << "Total Group: " << group_max;
			org = Point(0,(int)(0.98*frame.rows));

			putText(frame,sstm.str(),org,FONT_HERSHEY_PLAIN,1.5,(0,0,255),2,8);

        imshow("video", frame);
	
	//publish to "line_info" topic
	if(ros::ok()){
		
		//declare the msg name
		linedetection::line_info_msg msg;
		
		msg.line_stat = status;
		msg.d = d_main;
		msg.angle = angle_main;
		msg.frame_width = frame.cols;
		
		//publish msg
		vector_base_pub.publish(msg);
		
		if(msg.line_stat){
				cout << "d " << msg.d << " and angle" << msg.angle << "\n";
		}else{
				cout << "No line being detected\n";
		
		}
		
		ros::spinOnce();
	
	}

        if(waitKey(33) >= 0) break;

    }//end of for(;;)

    return 0;
}

