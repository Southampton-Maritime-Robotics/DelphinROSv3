#include <iostream>
#include <fstream>

#include <cv.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include "ros/ros.h"

using namespace std;
using namespace cv;

int main( int argc, char** argv){

	//~ //Open webcam
	VideoCapture cap(1);                          //'o' for integrated webcam, or '1' for external webcam
	if(!cap.isOpened()){                          // If an error occured...
		cout << "Error while opening Webcam.\n";
		return-1;                                 // ... quit the application
	}
	cout << "Webcam opened successfully !\n";

	Mat img;
	Mat img_gray;
	namedWindow("frame");
	Mat undist;
	
	int numCornersHor = 9;
	int numCornersVer = 6;

	int numSquares = numCornersHor * numCornersVer;
	
	Size patternsize(numCornersHor, numCornersVer);
	vector<Point2f> corners;

	vector< vector<Point3f> > obj_points;
	vector< vector<Point2f> > image_points;
	
	vector<Point3f> obj;
	
	for(int j = 0; j<numSquares;j++){
		obj.push_back(Point3f(j/numCornersHor, j%numCornersHor, 0.0f));
	}

	for(;;){
		
		cap >> img;
		cvtColor(img, img_gray, CV_BGR2GRAY);
		imshow("frame",img);
	
		bool found = cv::findChessboardCorners(img, patternsize, corners, CALIB_CB_ADAPTIVE_THRESH + CALIB_CB_NORMALIZE_IMAGE + CALIB_CB_FAST_CHECK);

		if(found){
			
			cout << "the pattern has been found" << endl;
			
			cornerSubPix(img_gray, corners, Size(11,11), Size(-1,-1), TermCriteria(CV_TERMCRIT_EPS + CV_TERMCRIT_ITER, 30, 0.1));
			drawChessboardCorners(img_gray, patternsize, corners, found);
			cout << "found";

			image_points.push_back(corners);
			obj_points.push_back(obj);

			Mat intrinsic = Mat(3,3,CV_32FC1);
			Mat distCoeffs;
			vector<Mat> rvecs;
			vector<Mat> tvecs;

			calibrateCamera( obj_points, image_points, img.size(), intrinsic, distCoeffs, rvecs, tvecs );

			ofstream myfileo ("coeff_mat.txt");
			
			cout << endl << intrinsic << endl << distCoeffs << endl;
			myfileo 	<< intrinsic.ptr<double>(0)[0] << endl
					<< intrinsic.ptr<double>(0)[1] << endl
					<< intrinsic.ptr<double>(0)[2] << endl
					<< intrinsic.ptr<double>(1)[0] << endl
					<< intrinsic.ptr<double>(1)[1] << endl
					<< intrinsic.ptr<double>(1)[2] << endl
					<< intrinsic.ptr<double>(2)[0] << endl
					<< intrinsic.ptr<double>(2)[1] << endl
					<< intrinsic.ptr<double>(2)[2] << endl
					<< distCoeffs.ptr<double>(0)[0] << endl
					<< distCoeffs.ptr<double>(0)[1] << endl
					<< distCoeffs.ptr<double>(0)[2] << endl
					<< distCoeffs.ptr<double>(0)[3] << endl
					<< distCoeffs.ptr<double>(0)[4] << endl;
			myfileo.close();
			
			cout << "finish saving" << endl;
			
			return 0;
		}
		
		if(waitKey(80) >= 0) break;

	}
		
	
	
    return 0;
}

